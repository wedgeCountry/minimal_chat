"""Application configuration loaded from environment variables and .env files.

The app is configured through environment variables. For local development
and deployments that ship a preset, variables can also live in a ``.env``
file (see the repository's ``env-example`` for the available presets):

    from user_registry import Config

    config = Config.from_env()          # loads ./.env, then reads the environment

Precedence: a variable already present in the real environment always wins
over the value from the ``.env`` file (``override=True`` flips this), and the
``.env`` file wins over the built-in defaults. ``.env`` is git-ignored; commit
presets as ``env-example`` instead.

The same ``Config`` class is the basis for the app in production
(``Config.from_env()``) and in tests, where a mapping or a temporary .env
file can be injected without touching the process environment::

    Config.from_env(env_file="tests/fixtures/.env.test")   # file + real env
    Config.from_env(env_file=None, environ={"USER_REGISTRY_SECRET_KEY": "..."})
    Config.from_mapping({"USER_REGISTRY_PORT": "8080"})

Use :func:`load_dotenv` alone when only the side effect on ``os.environ`` is
needed (e.g. so that :func:`user_registry.web.mount_auth` picks up
``USER_REGISTRY_SECRET_KEY`` without passing it explicitly).
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, fields
from typing import Any, Mapping, MutableMapping, Optional, Union

__all__ = [
    "Config",
    "DEFAULT_ENV_FILE",
    "ENV_PREFIX",
    "load_dotenv",
    "parse_dotenv",
]

PathLike = Union[str, "os.PathLike[str]"]

ENV_PREFIX = "USER_REGISTRY_"

DEFAULT_ENV_FILE = ".env"

_TRUE_VALUES = {"1", "true", "yes", "on"}
_FALSE_VALUES = {"0", "false", "no", "off", ""}

_DQ_ESCAPE_RE = re.compile(r"\\(.)")

_DQ_ESCAPES = {"n": "\n", "t": "\t", "r": "\r"}


def parse_dotenv(text: str) -> dict[str, str]:
    """Parse the content of a .env file into a ``dict``.

    Supported syntax: blank lines and ``#`` comments are skipped, an
    optional ``export `` prefix is allowed, values may be single- or
    double-quoted (double quotes process ``\\n``, ``\\t``, ``\\r``, ``\\"``
    and ``\\\\`` escapes; single quotes are literal), and unquoted values are
    cut at the first ``#`` that starts the value or follows whitespace
    (inline comment). Everything after the first ``=`` belongs to the value,
    so values may contain ``=``. ``KEY=`` yields an empty string.

    Raises ``ValueError`` on a non-comment line without ``=`` or with an
    empty/whitespace-containing key, so a malformed .env fails loudly.
    """
    result: dict[str, str] = {}
    for lineno, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export "):].strip()
        if "=" not in line:
            raise ValueError(
                f"invalid line {lineno} in .env file "
                f"(expected KEY=VALUE): {raw_line!r}"
            )
        key, _, value = line.partition("=")
        key = key.strip()
        if not key or any(ch.isspace() for ch in key):
            raise ValueError(
                f"invalid key on line {lineno} in .env file: {raw_line!r}"
            )
        value = value.strip()
        if (
            len(value) >= 2
            and value[0] in ("'", '"')
            and value[-1] == value[0]
        ):
            inner = value[1:-1]
            if value[0] == '"':
                inner = _DQ_ESCAPE_RE.sub(
                    lambda m: _DQ_ESCAPES.get(m.group(1), m.group(1)), inner
                )
            value = inner
        else:
            for i, ch in enumerate(value):
                if ch == "#" and (i == 0 or value[i - 1] in " \t"):
                    value = value[:i].rstrip()
                    break
        result[key] = value
    return result


def _find_dotenv(name: str) -> Optional[str]:
    """Return the nearest ``name`` in the cwd or a parent directory, or None."""
    current = os.path.abspath(os.getcwd())
    while True:
        candidate = os.path.join(current, name)
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            return None
        current = parent


def load_dotenv(
    dotenv_path: PathLike = DEFAULT_ENV_FILE,
    *,
    override: bool = False,
    environ: Optional[MutableMapping[str, str]] = None,
) -> dict[str, str]:
    """Load the variables of a .env file into the environment.

    ``environ`` defaults to ``os.environ``; pass any mutable mapping (e.g. a
    plain dict in tests) to keep the process environment untouched. A
    variable that already exists is kept unless ``override=True``, so real
    environment variables (secrets managers, CI, ...) take precedence over
    the file.

    A bare file name (the default ``.env``) that is not in the current working
    directory is searched in the parent directories, so running the app from
    any subdirectory of the project picks up the project-root ``.env``. A path
    containing a directory part is used as given.

    Returns the parsed variables (an empty dict if the file does not exist;
    a missing file is not an error).
    """
    if environ is None:
        environ = os.environ
    path = os.fspath(dotenv_path)
    if not os.path.isfile(path) and not os.path.dirname(path):
        found = _find_dotenv(os.path.basename(path))
        if found is not None:
            path = found
    if not os.path.isfile(path):
        return {}
    with open(path, "r", encoding="utf-8") as handle:
        parsed = parse_dotenv(handle.read())
    for key, value in parsed.items():
        if override or key not in environ:
            environ[key] = value
    return parsed


def _parse_bool(env_name: str, raw: str, fallback: bool) -> bool:
    if raw == "":
        return fallback
    normalized = raw.strip().lower()
    if normalized in _TRUE_VALUES:
        return True
    if normalized in _FALSE_VALUES:
        return False
    raise ValueError(
        f"{env_name} must be a boolean "
        f"(1/true/yes/on or 0/false/no/off), got {raw!r}"
    )


def _parse_int(env_name: str, raw: str, fallback: int) -> int:
    if raw == "":
        return fallback
    try:
        return int(raw.strip())
    except ValueError:
        raise ValueError(f"{env_name} must be an integer, got {raw!r}") from None


def _convert(env_name: str, raw: str, current: Any) -> Any:
    if isinstance(current, bool):
        return _parse_bool(env_name, raw, current)
    if isinstance(current, int):
        return _parse_int(env_name, raw, current)
    if current is None:
        return raw if raw != "" else None
    return raw if raw != "" else current


@dataclass
class Config:
    """Configuration of the app, loaded from environment variables / .env files.

    Every field maps to one environment variable,
    ``USER_REGISTRY_`` + the upper-cased field name (e.g. ``db_path`` ->
    ``USER_REGISTRY_DB_PATH``). Build it with :meth:`from_env` (production:
    real environment + ``.env`` file) or :meth:`from_mapping` (tests:
    inject a plain mapping).
    """

    db_path: str = "users.db"
    log_path: Optional[str] = None
    secret_key: Optional[str] = None
    server_kek: Optional[str] = None  # 32-byte hex, USER_REGISTRY_SERVER_KEK
    prefix: str = "/auth"
    host: str = "127.0.0.1"
    port: int = 5770
    base_url: Optional[str] = None
    terms_version: str = "1.0"
    terms_document: Optional[str] = None
    imprint_document: Optional[str] = None
    background_image: Optional[str] = None
    require_reaccept: bool = False
    require_invitation: bool = False
    login_redirect: Optional[str] = None
    session_cookie: str = "auth_session"
    csrf_cookie: str = "auth_csrf"
    session_max_age: int = 7 * 24 * 3600
    cookie_secure: bool = True
    login_max_attempts_per_day: int = 10
    write_fixture_dir: Optional[str] = None
    invite_email: str = "alice@example.com"
    invite_expires_in_days: int = 7

    @property
    def public_base_url(self) -> str:
        """Public base URL of the mounted auth UI.

        The explicit ``base_url`` if set, otherwise derived from ``host``,
        ``port`` and ``prefix``.
        """
        if self.base_url:
            return self.base_url.rstrip("/")
        return f"http://{self.host}:{self.port}{self.prefix}"

    @classmethod
    def from_mapping(cls, mapping: Mapping[str, str]) -> "Config":
        """Build a config from a mapping of environment variables.

        Unknown keys are ignored; empty values are treated as unset and fall
        back to the defaults. Raises ``ValueError`` for malformed booleans
        or integers.
        """
        config = cls()
        for field in fields(config):
            env_name = ENV_PREFIX + field.name.upper()
            if env_name in mapping:
                raw = mapping[env_name]
                setattr(
                    config, field.name, _convert(env_name, raw, getattr(config, field.name))
                )
        return config

    @classmethod
    def from_env(
        cls,
        env_file: Optional[PathLike] = DEFAULT_ENV_FILE,
        environ: Optional[MutableMapping[str, str]] = None,
        *,
        override: bool = False,
    ) -> "Config":
        """Build a config from a .env file plus the environment.

        ``env_file`` defaults to ``.env``, searched in the current working
        directory and then in its parents (see :func:`load_dotenv`); pass
        ``None`` to skip file loading. The file is loaded into ``environ``
        (default ``os.environ``), so the rest of the app sees the variables
        too. Real environment variables win over file values unless
        ``override=True``.
        """
        if environ is None:
            environ = os.environ
        if env_file is not None:
            load_dotenv(env_file, override=override, environ=environ)
        return cls.from_mapping(environ)

    def to_dict(self) -> dict[str, Any]:
        """Return the config as a plain dict keyed by field name."""
        return {field.name: getattr(self, field.name) for field in fields(self)}
