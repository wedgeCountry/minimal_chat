"""Single-file SQLite user registration library.

Concurrency model: the SQLite database runs in WAL mode and every mutating
operation (create / change password / delete) executes inside a single
``BEGIN IMMEDIATE`` transaction, so the database write lock is taken up front
and race conditions between concurrent operations are impossible. Uniqueness
of e-mail addresses is enforced by a database-level ``UNIQUE`` constraint,
not only in Python. All public methods are safe to call from multiple
threads (an in-process lock serializes access to the shared connection).

Logging: every mutating operation appends one line to a log file
(``<db_path>.log`` unless ``log_path`` is given) containing a timestamp, the
operation name and the affected e-mail address. Passwords and password
hashes are never written to the log.
"""

from __future__ import annotations

import hashlib
import logging
import os
import re
import secrets
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from typing import Optional, Union

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHash, VerificationError, VerifyMismatchError
from argon2.low_level import Type as Argon2Type
from argon2.low_level import hash_secret_raw

from user_registry._password_policy import password_policy_error

__all__ = ["UserAlreadyExistsError", "UserRegistry"]

__version__ = "0.1.0"

PathLike = Union[str, "os.PathLike[str]"]

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

_MAX_EMAIL_LENGTH = 254

_hasher = PasswordHasher()

# Verified against for unknown users so that verify_password (and the key
# accessors) pay the same Argon2 cost whether or not the e-mail exists,
# removing the user-enumeration timing signal.
_DUMMY_HASH = _hasher.hash(secrets.token_urlsafe(32))

_VERIFY_ERRORS = (VerifyMismatchError, VerificationError, InvalidHash)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _new_encryption_key() -> str:
    return secrets.token_hex(32)


def _derive_key(password: str, key_hex: str) -> bytes:
    return hash_secret_raw(
        password.encode("utf-8"),
        bytes.fromhex(key_hex),
        time_cost=3,
        memory_cost=65536,
        parallelism=4,
        hash_len=32,
        type=Argon2Type.ID,
    )


class UserAlreadyExistsError(Exception):
    """Raised when creating a user whose e-mail address is already registered."""


class UserRegistry:
    """User registry backed by a single SQLite database file.

    Parameters
    ----------
    db_path:
        Path to the SQLite database file. Created by :meth:`init_db`.
    log_path:
        Path to the operation log file. Defaults to ``"<db_path>.log"``.

    The registry is not usable until :meth:`init_db` has been called. Any
    operation invoked before :meth:`init_db` or after :meth:`close` raises
    ``RuntimeError``.
    """

    def __init__(self, db_path: PathLike, log_path: Optional[PathLike] = None) -> None:
        self.db_path = db_path
        self.log_path = str(log_path) if log_path is not None else str(db_path) + ".log"
        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None
        self._logger = logging.getLogger(f"user_registry.{id(self)}")
        self._logger.setLevel(logging.INFO)
        self._logger.propagate = False
        self._handler = logging.FileHandler(self.log_path)
        self._handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s %(message)s")
        )
        self._logger.addHandler(self._handler)
        try:
            os.chmod(self.log_path, 0o600)
        except OSError:
            pass

    def _require_open(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError(
                "UserRegistry is not initialized; call init_db() first "
                "(or the registry was closed)"
            )
        return self._conn

    @staticmethod
    def _normalize_email(email: str) -> str:
        return email.strip().lower()

    @staticmethod
    def _validate_email(email: str) -> None:
        if len(email) > _MAX_EMAIL_LENGTH:
            raise ValueError(
                f"email address must not exceed {_MAX_EMAIL_LENGTH} characters"
            )
        if not _EMAIL_RE.match(email):
            raise ValueError(f"invalid email address: {email!r}")

    def init_db(self) -> None:
        """Create the database file and schema if they do not exist yet.

        Idempotent: calling it again on an initialized registry preserves all
        existing data. Creates the ``users`` table with columns ``id``,
        ``email`` (``UNIQUE``), ``display_name``, ``password_hash``,
        ``created_at``, ``updated_at``, ``password_changed_at`` and
        ``encryption_key``, the ``terms_acceptances``, ``invitations`` and
        ``password_resets`` tables, and enables WAL journal mode. Databases
        created by older versions are migrated in place:
        ``password_changed_at`` is added and backfilled from ``updated_at``,
        and ``encryption_key`` is added and backfilled with a fresh random
        value per user.
        """
        with self._lock:
            if self._conn is not None:
                return
            conn = sqlite3.connect(
                str(self.db_path), check_same_thread=False, isolation_level=None
            )
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    email TEXT NOT NULL UNIQUE,
                    display_name TEXT NOT NULL,
                    password_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    password_changed_at TEXT NOT NULL,
                    encryption_key TEXT NOT NULL
                )
                """
            )
            columns = {
                row[1] for row in conn.execute("PRAGMA table_info(users)").fetchall()
            }
            if "password_changed_at" not in columns:
                conn.execute("ALTER TABLE users ADD COLUMN password_changed_at TEXT")
                conn.execute("UPDATE users SET password_changed_at = updated_at")
            if "encryption_key" not in columns:
                conn.execute("ALTER TABLE users ADD COLUMN encryption_key TEXT")
                for (user_id,) in conn.execute("SELECT id FROM users").fetchall():
                    conn.execute(
                        "UPDATE users SET encryption_key = ? WHERE id = ?",
                        (_new_encryption_key(), user_id),
                    )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS terms_acceptances (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    terms_version TEXT NOT NULL,
                    accepted_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS invitations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    token_hash TEXT NOT NULL UNIQUE,
                    email TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    used_at TEXT
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS password_resets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    token_hash TEXT NOT NULL UNIQUE,
                    email TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    used_at TEXT
                )
                """
            )
            self._conn = conn

    def user_exists(self, email: str) -> bool:
        """Return ``True`` if a user with ``email`` is registered.

        The lookup is case-insensitive. Returns ``False`` for unknown users.
        """
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT 1 FROM users WHERE email = ?",
                (self._normalize_email(email),),
            ).fetchone()
            return row is not None

    def password_changed_at(self, email: str) -> Optional[str]:
        """Return the UTC timestamp of the last password change for ``email``.

        The value is set at registration and bumped by every successful
        :meth:`change_password` and :meth:`reset_password` call, so it can
        serve as a session epoch: any change invalidates previously issued
        sessions. Returns ``None`` for unknown users.
        """
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT password_changed_at FROM users WHERE email = ?",
                (self._normalize_email(email),),
            ).fetchone()
        return row[0] if row is not None else None

    def create_user(
        self, email: str, password: str, display_name: str, terms_version: str
    ) -> int:
        """Register a new user and return the new user's id (``int``).

        ``email`` is normalized to lowercase; ``display_name`` is stripped of
        surrounding whitespace. The password is stored only as a salted
        Argon2id hash — never in plaintext. A cryptographically secure random
        per-user encryption key is generated once and stored in the
        ``encryption_key`` column; :meth:`get_encryption_key` releases it after
        verifying the password, :meth:`get_private_encryption_key` derives a
        second key from password + stored key. ``terms_version`` records which
        version of the terms and conditions (AGB) the user accepted; the
        acceptance is stored in the same transaction as the user row.

        Raises
        ------
        ValueError
            If the e-mail is malformed, the password is empty/whitespace-only,
            the display name is empty/whitespace-only, or ``terms_version``
            is empty.
        UserAlreadyExistsError
            If the e-mail is already registered (case-insensitive).
        """
        email = self._normalize_email(email)
        self._validate_email(email)
        if not password or not password.strip():
            raise ValueError("password must not be empty")
        policy_error = password_policy_error(password)
        if policy_error:
            raise ValueError(policy_error)
        display_name = display_name.strip()
        if not display_name:
            raise ValueError("display_name must not be empty")
        if not terms_version or not terms_version.strip():
            raise ValueError("terms_version must not be empty")
        terms_version = terms_version.strip()
        pw_hash = _hasher.hash(password)
        encryption_key = _new_encryption_key()
        now = _utc_now()
        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                cursor = conn.execute(
                    "INSERT INTO users (email, display_name, password_hash,"
                    " encryption_key, created_at, updated_at, password_changed_at)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (email, display_name, pw_hash, encryption_key, now, now, now),
                )
                user_id = cursor.lastrowid
                conn.execute(
                    "INSERT INTO terms_acceptances (user_id, terms_version,"
                    " accepted_at) VALUES (?, ?, ?)",
                    (user_id, terms_version, now),
                )
                conn.execute("COMMIT")
            except sqlite3.IntegrityError:
                conn.execute("ROLLBACK")
                raise UserAlreadyExistsError(
                    f"user already registered: {email}"
                ) from None
        self._logger.info(
            "create_user email=%s id=%s terms_version=%s", email, user_id, terms_version
        )
        return user_id

    def get_terms_acceptance(self, email: str) -> Optional[dict]:
        """Return the latest AGB acceptance for ``email``.

        Returns ``{"terms_version": str, "accepted_at": str}`` or ``None``
        if the user does not exist or never accepted the terms.
        """
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT ta.terms_version, ta.accepted_at FROM terms_acceptances ta"
                " JOIN users u ON u.id = ta.user_id WHERE u.email = ?"
                " ORDER BY ta.id DESC LIMIT 1",
                (self._normalize_email(email),),
            ).fetchone()
        if row is None:
            return None
        return {"terms_version": row[0], "accepted_at": row[1]}

    def get_encryption_key(self, email: str, password: str) -> Optional[bytes]:
        """Return the DB-save file-encryption key of user ``email``.

        This is the **stored-key** encryption path. A cryptographically
        secure random 32-byte key is generated once at registration and
        stored in the ``encryption_key`` column of the ``users`` table.
        The password is verified against the stored Argon2id hash first;
        only a correct password releases the stored key, which can encrypt
        and decrypt the user's data files.

        Difference to :meth:`get_private_encryption_key`:

        - the key does **not** depend on the password, so it stays the same
          when the password is changed or reset via token — files encrypted
          with it remain decryptable after a password reset;
        - the key **is** stored server-side, so anyone with database access
          can compute it without knowing the password; the password acts
          only as an access gate for API callers.

        Returns ``None`` if the user does not exist or the password is
        wrong, so no key is released for an unauthenticated caller. The
        e-mail lookup is case-insensitive. The key is never written to the
        log file.
        """
        email = self._normalize_email(email)
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT password_hash, encryption_key FROM users WHERE email = ?",
                (email,),
            ).fetchone()
        if row is None:
            try:
                _hasher.verify(_DUMMY_HASH, password)
            except _VERIFY_ERRORS:
                pass
            return None
        try:
            _hasher.verify(row[0], password)
        except _VERIFY_ERRORS:
            return None
        return bytes.fromhex(row[1])

    def get_private_encryption_key(self, email: str, password: str) -> Optional[bytes]:
        """Return the API-save file-encryption key of user ``email``.

        This is the **password-derived** encryption path. The 32-byte key
        is derived with Argon2id (memory-hard) from the password and the
        per-user ``encryption_key`` stored in the ``users`` table
        (generated once at registration), which makes the derived key unique
        per user. The derived key itself is **never stored** anywhere; it
        can be recomputed at any time from the correct password.

        Difference to :meth:`get_encryption_key`:

        - a database leak alone does **not** reveal the key — an attacker
          still has to brute-force the password, which Argon2id makes
          expensive;
        - the key **does** depend on the password, so it changes on every
          password change and on every token-based password reset — files
          encrypted with the old key become unreadable after a reset.

        Returns ``None`` if the user does not exist or the password is
        wrong, so no key is released for an unauthenticated caller. The
        e-mail lookup is case-insensitive. Neither key is written to the
        log file.
        """
        email = self._normalize_email(email)
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT password_hash, encryption_key FROM users WHERE email = ?",
                (email,),
            ).fetchone()
        if row is None:
            try:
                _hasher.verify(_DUMMY_HASH, password)
            except _VERIFY_ERRORS:
                pass
            return None
        try:
            _hasher.verify(row[0], password)
        except _VERIFY_ERRORS:
            return None
        return _derive_key(password, row[1])

    def create_invitation(self, email: str, expires_in_seconds: int) -> str:
        """Create a single-use invitation for ``email`` and return its token.

        The token is returned once and is never stored; only its SHA-256
        hash is persisted in the ``invitations`` table, together with the
        normalized e-mail address the invitation is bound to and the expiry
        timestamp. The token never appears in the log file.

        Raises
        ------
        ValueError
            If the e-mail is malformed or ``expires_in_seconds`` is not
            a positive integer.
        """
        email = self._normalize_email(email)
        self._validate_email(email)
        if not isinstance(expires_in_seconds, int) or expires_in_seconds < 1:
            raise ValueError("expires_in_seconds must be a positive integer")
        token = secrets.token_urlsafe(32)
        now = datetime.now(timezone.utc)
        expires_at = (now + timedelta(seconds=expires_in_seconds)).isoformat(
            timespec="microseconds"
        )

        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT 1 FROM users WHERE email = ?", (email,)
            ).fetchone()

        if row is not None:
            raise ValueError(f"User {email} is already registered!")


        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                conn.execute(
                    "INSERT INTO invitations (token_hash, email, created_at,"
                    " expires_at) VALUES (?, ?, ?, ?)",
                    (_token_hash(token), email, now.isoformat(), expires_at),
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
        self._logger.info(
            "create_invitation email=%s expires_at=%s", email, expires_at
        )
        return token

    def invitation_valid(self, token: str, email: str) -> bool:
        """Return ``True`` if ``token`` is an unused, unexpired invitation for ``email``.

        The e-mail comparison is case-insensitive. Returns ``False`` for
        unknown tokens, already-used or expired invitations and for a
        mismatching e-mail address.
        """
        if not token:
            return False
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT email, expires_at, used_at FROM invitations"
                " WHERE token_hash = ?",
                (_token_hash(token),),
            ).fetchone()
        if row is None or row[2] is not None:
            return False
        if row[0] != self._normalize_email(email):
            return False
        if datetime.fromisoformat(row[1]) <= datetime.now(timezone.utc):
            return False
        return True

    def invitation_token_valid(self, token: str) -> bool:
        """Return ``True`` if ``token`` is an unused, unexpired invitation token.

        Unlike :meth:`invitation_valid` this does not check the e-mail
        binding, so it can be used to gate pages that only receive the token
        (e.g. ``/register?invite=<token>``). Returns ``False`` for unknown,
        already-used or expired tokens.
        """
        if not token:
            return False
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT expires_at, used_at FROM invitations WHERE token_hash = ?",
                (_token_hash(token),),
            ).fetchone()
        if row is None or row[1] is not None:
            return False
        if datetime.fromisoformat(row[0]) <= datetime.now(timezone.utc):
            return False
        return True

    def invitation_email(self, token: str) -> Optional[str]:
        """Return the e-mail address a valid invitation ``token`` is bound to.

        Returns the normalized e-mail address if ``token`` is an unused,
        unexpired invitation token, otherwise ``None``.
        """
        if not token:
            return None
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT email, expires_at, used_at FROM invitations"
                " WHERE token_hash = ?",
                (_token_hash(token),),
            ).fetchone()
        if row is None or row[2] is not None:
            return None
        if datetime.fromisoformat(row[1]) <= datetime.now(timezone.utc):
            return None
        return row[0]


    def consume_invitation(self, token: str, email: str) -> bool:
        """Mark the invitation ``token`` as used; return ``True`` if it was valid.

        The check and the update run in a single ``BEGIN IMMEDIATE``
        transaction, so a single-use invitation can never be consumed twice,
        even under concurrency. Returns ``False`` if the token is unknown,
        already used, expired or bound to a different e-mail address.
        """
        if not token:
            return False
        now = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                cursor = conn.execute(
                    "UPDATE invitations SET used_at = ? WHERE token_hash = ?"
                    " AND email = ? AND used_at IS NULL AND expires_at > ?",
                    (now, _token_hash(token), self._normalize_email(email), now),
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
            consumed = cursor.rowcount > 0
        if consumed:
            self._logger.info(
                "consume_invitation email=%s", self._normalize_email(email)
            )
        return consumed

    def create_password_reset(self, email: str, expires_in_seconds: int) -> Optional[str]:
        """Create a single-use password-reset token for ``email``; return it.

        Returns ``None`` if no user with ``email`` is registered, so callers
        can answer uniformly without revealing whether an account exists.
        The token is returned once and is never stored; only its SHA-256 hash
        is persisted in the ``password_resets`` table together with the
        normalized e-mail address and the expiry timestamp. The token never
        appears in the log file.

        Raises
        ------
        ValueError
            If the e-mail is malformed or ``expires_in_seconds`` is not
            a positive integer.
        """
        email = self._normalize_email(email)
        self._validate_email(email)
        if not isinstance(expires_in_seconds, int) or expires_in_seconds < 1:
            raise ValueError("expires_in_seconds must be a positive integer")

        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT 1 FROM users WHERE email = ?", (email,)
            ).fetchone()

        if row is None:
            raise ValueError(f"User {email} is not registered")

        token = secrets.token_urlsafe(32)
        now = datetime.now(timezone.utc)
        expires_at = (now + timedelta(seconds=expires_in_seconds)).isoformat(
            timespec="microseconds"
        )

        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                conn.execute(
                    "INSERT INTO password_resets (token_hash, email, created_at,"
                    " expires_at) VALUES (?, ?, ?, ?)",
                    (_token_hash(token), email, now.isoformat(), expires_at),
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
        self._logger.info(
            "create_password_reset email=%s expires_at=%s", email, expires_at
        )
        return token

    def password_reset_valid(self, token: str) -> bool:
        """Return ``True`` if ``token`` is an unused, unexpired password-reset token.

        Returns ``False`` for unknown, already-used or expired tokens.
        """
        if not token:
            return False
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT expires_at, used_at FROM password_resets WHERE token_hash = ?",
                (_token_hash(token),),
            ).fetchone()
        if row is None or row[1] is not None:
            return False
        if datetime.fromisoformat(row[0]) <= datetime.now(timezone.utc):
            return False
        return True

    def password_reset_email(self, token: str) -> Optional[str]:
        """Return the e-mail address a valid reset ``token`` is bound to.

        Returns the normalized e-mail address if ``token`` is an unused,
        unexpired password-reset token, otherwise ``None``.
        """
        if not token:
            return None
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT email, expires_at, used_at FROM password_resets"
                " WHERE token_hash = ?",
                (_token_hash(token),),
            ).fetchone()
        if row is None or row[2] is not None:
            return None
        if datetime.fromisoformat(row[1]) <= datetime.now(timezone.utc):
            return None
        return row[0]

    def reset_password(self, token: str, new_password: str) -> bool:
        """Set a new password using a single-use reset ``token``; return ``True`` on success.

        The token check, the password update and the token consumption run
        in a single ``BEGIN IMMEDIATE`` transaction, so a reset token can
        never be used twice, even under concurrency. Returns ``False`` if the
        token is unknown, already used or expired; the stored password is
        left unchanged in that case.

        Raises
        ------
        ValueError
            If ``new_password`` is empty/whitespace-only or violates the
            password policy.
        """
        if not new_password or not new_password.strip():
            raise ValueError("new_password must not be empty")
        policy_error = password_policy_error(new_password)
        if policy_error:
            raise ValueError(policy_error)
        if not token:
            return False
        now = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                row = conn.execute(
                    "SELECT email, expires_at, used_at FROM password_resets"
                    " WHERE token_hash = ?",
                    (_token_hash(token),),
                ).fetchone()
                if (
                    row is None
                    or row[2] is not None
                    or datetime.fromisoformat(row[1]) <= datetime.now(timezone.utc)
                ):
                    conn.execute("ROLLBACK")
                    return False
                email = row[0]
                changed_at = _utc_now()
                conn.execute(
                    "UPDATE users SET password_hash = ?, updated_at = ?,"
                    " password_changed_at = ? WHERE email = ?",
                    (_hasher.hash(new_password), changed_at, changed_at, email),
                )
                conn.execute(
                    "UPDATE password_resets SET used_at = ? WHERE token_hash = ?",
                    (now, _token_hash(token)),
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
        self._logger.info("reset_password email=%s", email)
        return True

    def verify_password(self, email: str, password: str) -> bool:
        """Return ``True`` if ``password`` is correct for the user ``email``.

        Returns ``False`` both for wrong passwords and for unknown users.
        Password comparison is case-sensitive; e-mail lookup is not.
        """
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT password_hash FROM users WHERE email = ?",
                (self._normalize_email(email),),
            ).fetchone()
        if row is None:
            try:
                _hasher.verify(_DUMMY_HASH, password)
            except _VERIFY_ERRORS:
                pass
            return False
        try:
            return _hasher.verify(row[0], password)
        except _VERIFY_ERRORS:
            return False

    def change_password(self, email: str, old_password: str, new_password: str) -> bool:
        """Change the password of user ``email``; return ``True`` on success.

        Returns ``False`` if the user does not exist or ``old_password`` is
        wrong; in that case the stored password is left unchanged. All
        outstanding password-reset tokens of the user are invalidated in
        the same transaction.

        Raises
        ------
        ValueError
            If ``new_password`` is empty/whitespace-only or violates the
            password policy.
        """
        if not new_password or not new_password.strip():
            raise ValueError("new_password must not be empty")
        policy_error = password_policy_error(new_password)
        if policy_error:
            raise ValueError(policy_error)
        email = self._normalize_email(email)
        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                row = conn.execute(
                    "SELECT password_hash FROM users WHERE email = ?", (email,)
                ).fetchone()
                if row is None:
                    conn.execute("ROLLBACK")
                    return False
                try:
                    old_ok = _hasher.verify(row[0], old_password)
                except _VERIFY_ERRORS:
                    old_ok = False
                if not old_ok:
                    conn.execute("ROLLBACK")
                    return False
                changed_at = _utc_now()
                conn.execute(
                    "UPDATE users SET password_hash = ?, updated_at = ?,"
                    " password_changed_at = ? WHERE email = ?",
                    (_hasher.hash(new_password), changed_at, changed_at, email),
                )
                conn.execute(
                    "DELETE FROM password_resets WHERE email = ?", (email,)
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
        self._logger.info("change_password email=%s", email)
        return True

    def delete_user(self, email: str) -> bool:
        """Delete the user ``email``; return ``True`` if a user was deleted.

        Returns ``False`` if no such user exists (the call is then a no-op).
        After deletion the e-mail address may be registered again. All
        outstanding password-reset tokens of the user are deleted in the
        same transaction, so a token minted before the deletion cannot be
        used on a later account registered under the same e-mail address.
        """
        email = self._normalize_email(email)
        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                cursor = conn.execute(
                    "DELETE FROM users WHERE email = ?", (email,)
                )
                conn.execute(
                    "DELETE FROM password_resets WHERE email = ?", (email,)
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
            deleted = cursor.rowcount > 0
        if deleted:
            self._logger.info("delete_user email=%s", email)
        return deleted

    def close(self) -> None:
        """Close the database connection and the log file. Idempotent."""
        with self._lock:
            if self._conn is not None:
                self._conn.close()
                self._conn = None
            if self._handler is not None:
                self._logger.removeHandler(self._handler)
                self._handler.close()
                self._handler = None

    def __enter__(self) -> "UserRegistry":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
