"""Single-file SQLite user registration library.

Concurrency model: the SQLite database runs in WAL mode and every mutating
operation (create / change password / delete) executes inside a single
``BEGIN IMMEDIATE`` transaction, so the database write lock is taken up front
and race conditions between concurrent operations are impossible. Uniqueness
of e-mail addresses is enforced by a database-level ``UNIQUE`` constraint,
not only in Python. All public methods are safe to call from multiple
threads (an in-process lock serializes access to the shared connection).

Logging: every mutating operation appends one line to a log file
(``<db_path>.log`` unless ``log_path`` is given) containing a timestamp, the
operation name and the affected e-mail address. Passwords and password
hashes are never written to the log.
"""

from __future__ import annotations

import hashlib
import importlib.resources as resources
import logging
import os
import re
import secrets
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from typing import Optional, Union

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHash, VerificationError, VerifyMismatchError
from argon2.low_level import Type as Argon2Type
from argon2.low_level import hash_secret_raw
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from user_registry._password_policy import password_policy_error
from user_registry.config import Config, load_dotenv, parse_dotenv

__all__ = [
    "Config",
    "PasswordResetNotAllowedError",
    "UserAlreadyExistsError",
    "UserRegistry",
    "load_dotenv",
    "parse_dotenv",
]

__version__ = "0.1.0"

PathLike = Union[str, "os.PathLike[str]"]

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

_MAX_EMAIL_LENGTH = 254

_hasher = PasswordHasher()

# Verified against for unknown users so that verify_password (and the key
# accessors) pay the same Argon2 cost whether or not the e-mail exists,
# removing the user-enumeration timing signal.
_DUMMY_HASH = _hasher.hash(secrets.token_urlsafe(32))

_VERIFY_ERRORS = (VerifyMismatchError, VerificationError, InvalidHash)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _new_encryption_key() -> str:
    return secrets.token_hex(32)


def _derive_key(password: str, key_hex: str) -> bytes:
    return hash_secret_raw(
        password.encode("utf-8"),
        bytes.fromhex(key_hex),
        time_cost=3,
        memory_cost=65536,
        parallelism=4,
        hash_len=32,
        type=Argon2Type.ID,
    )


# --- DEK/KEK envelope encryption ---------------------------------------------
#
# Every user has one random 32-byte DEK (data encryption key). The DEK is
# never stored in plaintext; it is only stored wrapped (AES-256-GCM) under a
# KEK (key encryption key):
#
# - key_mode "server" (default): DEK wrapped under the server KEK
#   (``server_kek`` constructor argument or the ``USER_REGISTRY_SERVER_KEK``
#   environment variable). Password reset stays possible; anyone who can
#   reach the KEK can unwrap.
# - key_mode "private": DEK wrapped under a KEK derived from the user's
#   password with Argon2id (Posteo-style zero-access). Password reset is not
#   possible for such accounts (the wrapped DEK would become undecryptable);
#   a normal password change re-wraps the DEK and keeps the data readable.
# - key_mode "both": both wraps of the same DEK are stored.
#
# Envelope (hex-encoded in the database):
#   version(1 byte = 0x01)
#   | server: kek_id (8 bytes = sha256(server_kek)[:8])
#     private: argon2id salt (16 bytes)
#   | nonce (12 bytes) | ciphertext (32 bytes) + GCM tag (16 bytes)
# AAD = b"user-registry/dek/v1/<mode>/<normalized email>", so a wrapped DEK
# cannot be swapped between users or modes undetected.

SERVER_KEK_ENV_VAR = "USER_REGISTRY_SERVER_KEK"

KEY_MODES = ("server", "private", "both")

_DEK_ENVELOPE_VERSION = 1
_DEK_NONCE_BYTES = 12
_DEK_TAG_BYTES = 16
_PRIVATE_SALT_BYTES = 16
_KEK_ID_BYTES = 8
_DEK_AAD_PREFIX = "user-registry/dek/v1/"


def _dek_aad(mode: str, email: str) -> bytes:
    return f"{_DEK_AAD_PREFIX}{mode}/{email}".encode("utf-8")


def _password_kek(password: str, salt: bytes) -> bytes:
    return hash_secret_raw(
        password.encode("utf-8"),
        salt,
        time_cost=3,
        memory_cost=65536,
        parallelism=4,
        hash_len=32,
        type=Argon2Type.ID,
    )


def _kek_id(kek: bytes) -> bytes:
    return hashlib.sha256(kek).digest()[:_KEK_ID_BYTES]


def _wrap_dek(kek: bytes, dek: bytes, mode: str, email: str, header: bytes) -> str:
    nonce = secrets.token_bytes(_DEK_NONCE_BYTES)
    ct = AESGCM(kek).encrypt(nonce, dek, _dek_aad(mode, email))
    return (
        bytes([_DEK_ENVELOPE_VERSION]).hex() + header.hex() + nonce.hex() + ct.hex()
    )


def _unwrap_dek(blob_hex: str, kek: bytes, mode: str, email: str, header_len: int) -> bytes:
    raw = bytes.fromhex(blob_hex)
    if (
        len(raw) != 1 + header_len + _DEK_NONCE_BYTES + 32 + _DEK_TAG_BYTES
        or raw[0] != _DEK_ENVELOPE_VERSION
    ):
        raise ValueError("unsupported or corrupted wrapped-DEK envelope")
    nonce = raw[1 + header_len : 1 + header_len + _DEK_NONCE_BYTES]
    ct = raw[1 + header_len + _DEK_NONCE_BYTES :]
    try:
        return AESGCM(kek).decrypt(nonce, ct, _dek_aad(mode, email))
    except InvalidTag:
        raise RuntimeError(
            "wrapped DEK failed the integrity check (wrong KEK or tampered data)"
        ) from None


def _wrap_dek_server(dek: bytes, email: str, kek: bytes) -> str:
    return _wrap_dek(kek, dek, "server", email, _kek_id(kek))


def _unwrap_dek_server(blob_hex: str, email: str, kek: bytes) -> bytes:
    if bytes.fromhex(blob_hex)[1 : 1 + _KEK_ID_BYTES] != _kek_id(kek):
        raise RuntimeError(
            "server KEK does not match the wrapped DEK (wrong server_kek or "
            f"{SERVER_KEK_ENV_VAR}?)"
        )
    return _unwrap_dek(blob_hex, kek, "server", email, _KEK_ID_BYTES)


def _wrap_dek_private(dek: bytes, password: str, email: str) -> str:
    salt = secrets.token_bytes(_PRIVATE_SALT_BYTES)
    return _wrap_dek(_password_kek(password, salt), dek, "private", email, salt)


def _unwrap_dek_private(blob_hex: str, password: str, email: str) -> bytes:
    salt = bytes.fromhex(blob_hex)[1 : 1 + _PRIVATE_SALT_BYTES]
    return _unwrap_dek(
        blob_hex, _password_kek(password, salt), "private", email, _PRIVATE_SALT_BYTES
    )


class UserAlreadyExistsError(Exception):
    """Raised when creating a user whose e-mail address is already registered."""


class PasswordResetNotAllowedError(Exception):
    """Raised by :meth:`UserRegistry.reset_password` for accounts whose DEK is
    wrapped under the password-derived KEK (``key_mode`` ``"private"`` or
    ``"both"``): without the old password the wrapped DEK cannot be re-wrapped,
    so a token-based reset would make the user's encrypted data unreadable.
    Pass ``allow_data_loss=True`` to reset anyway, or use
    :meth:`UserRegistry.change_password` instead."""


class UserRegistry:
    """User registry backed by a single SQLite database file.

    Parameters
    ----------
    db_path:
        Path to the SQLite database file. Created by :meth:`init_db`.
    log_path:
        Path to the operation log file. Defaults to ``"<db_path>.log"``.
    server_kek:
        The 32-byte server key encryption key (KEK) used to wrap per-user DEKs
        for ``key_mode="server"`` (the default) and ``"both"`` accounts, as
        ``bytes`` or a 64-char hex string. If omitted, the
        ``USER_REGISTRY_SERVER_KEK`` environment variable (hex) is used; if
        neither is set, no server wrap can be created and ``create_user`` with
        a server mode raises ``ValueError``. Keep the KEK in a secrets manager
        or HSM-backed KMS in production: anyone who can reach it can unwrap
        server-mode DEKs.

    The registry is not usable until :meth:`init_db` has been called. Any
    operation invoked before :meth:`init_db` or after :meth:`close` raises
    ``RuntimeError``.
    """

    def __init__(
        self,
        db_path: PathLike,
        log_path: Optional[PathLike] = None,
        server_kek: Optional[Union[str, bytes]] = None,
    ) -> None:
        self.db_path = db_path
        self.log_path = str(log_path) if log_path is not None else str(db_path) + ".log"
        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None
        self._server_kek = self._resolve_server_kek(server_kek)
        self._key_shred_value: Optional[str] = None
        self._logger = logging.getLogger(f"user_registry.{id(self)}")
        self._logger.setLevel(logging.INFO)
        self._logger.propagate = False
        self._handler = logging.FileHandler(self.log_path)
        self._handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s %(message)s")
        )
        self._logger.addHandler(self._handler)
        try:
            os.chmod(self.log_path, 0o600)
        except OSError:
            pass

    @classmethod
    def from_config(cls, config: Config) -> "UserRegistry":
        """Create a registry from a :class:`user_registry.Config`.

        Uses ``config.db_path``, ``config.log_path`` (``None`` falls back
        to ``"<db_path>.log"``) and ``config.server_kek`` (the server KEK
        for ``key_mode="server"``/``"both"`` DEK wrapping).
        """
        return cls(
            config.db_path,
            log_path=config.log_path,
            server_kek=config.server_kek,
        )

    @staticmethod
    def _resolve_server_kek(server_kek: Optional[Union[str, bytes]]) -> Optional[bytes]:
        if server_kek is None or server_kek == "":
            server_kek = os.environ.get(SERVER_KEK_ENV_VAR)
        if server_kek is None or server_kek == "":
            return None
        if isinstance(server_kek, str):
            try:
                kek = bytes.fromhex(server_kek)
            except ValueError:
                raise ValueError(
                    f"server_kek must be a 64-char hex string (or set {SERVER_KEK_ENV_VAR})"
                ) from None
        elif isinstance(server_kek, (bytes, bytearray)):
            kek = bytes(server_kek)
        else:
            raise ValueError("server_kek must be 32 bytes or a 64-char hex string")
        if len(kek) != 32:
            raise ValueError("server_kek must be exactly 32 bytes (64 hex chars)")
        return kek

    def _require_open(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError(
                "UserRegistry is not initialized; call init_db() first "
                "(or the registry was closed)"
            )
        return self._conn

    @staticmethod
    def _normalize_email(email: str) -> str:
        return email.strip().lower()

    @staticmethod
    def _validate_email(email: str) -> None:
        if len(email) > _MAX_EMAIL_LENGTH:
            raise ValueError(
                f"email address must not exceed {_MAX_EMAIL_LENGTH} characters"
            )
        if not _EMAIL_RE.match(email):
            raise ValueError(f"invalid email address: {email!r}")

    def init_db(self) -> None:
        """Create the database file and schema if they do not exist yet.

        Idempotent: calling it again on an initialized registry preserves all
        existing data. Creates the ``users`` table with columns ``id``,
        ``email`` (``UNIQUE``), ``display_name``, ``password_hash``,
        ``created_at``, ``updated_at``, ``password_changed_at`` and
        ``encryption_key``, the ``terms_acceptances``, ``invitations`` and
        ``password_resets`` tables, and enables WAL journal mode. Databases
        created by older versions are migrated in place:
        ``password_changed_at`` is added and backfilled from ``updated_at``,
        and ``encryption_key`` is added and backfilled with a fresh random
        value per user. The DEK/KEK columns ``key_mode``, ``dek_wrapped_server``
        and ``dek_wrapped_private`` are added as well; when a server KEK is
        configured, legacy plaintext ``encryption_key`` values are wrapped
        into ``dek_wrapped_server`` and the plaintext is shredded (set to
        ``NULL``, or ``''`` on old schemas where the column is ``NOT NULL``).
        """
        with self._lock:
            if self._conn is not None:
                return
            conn = sqlite3.connect(
                str(self.db_path), check_same_thread=False, isolation_level=None
            )
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            conn.executescript(
                resources.files("user_registry")
                .joinpath("schema.sql")
                .read_text(encoding="utf-8")
            )
            columns = {
                row[1] for row in conn.execute("PRAGMA table_info(users)").fetchall()
            }
            if "password_changed_at" not in columns:
                conn.execute("ALTER TABLE users ADD COLUMN password_changed_at TEXT")
                conn.execute("UPDATE users SET password_changed_at = updated_at")
            if "encryption_key" not in columns:
                conn.execute("ALTER TABLE users ADD COLUMN encryption_key TEXT")
                for (user_id,) in conn.execute("SELECT id FROM users").fetchall():
                    conn.execute(
                        "UPDATE users SET encryption_key = ? WHERE id = ?",
                        (_new_encryption_key(), user_id),
                    )
            if "key_mode" not in columns:
                conn.execute(
                    "ALTER TABLE users ADD COLUMN key_mode TEXT NOT NULL DEFAULT 'server'"
                )
            if "dek_wrapped_server" not in columns:
                conn.execute("ALTER TABLE users ADD COLUMN dek_wrapped_server TEXT")
            if "dek_wrapped_private" not in columns:
                conn.execute("ALTER TABLE users ADD COLUMN dek_wrapped_private TEXT")
            info = conn.execute("PRAGMA table_info(users)").fetchall()
            self._key_shred_value = (
                "" if any(r[1] == "encryption_key" and r[3] for r in info) else None
            )
            if self._server_kek is not None:
                for user_id, email, key_hex in conn.execute(
                    "SELECT id, email, encryption_key FROM users"
                    " WHERE encryption_key IS NOT NULL AND encryption_key != ''"
                    " AND dek_wrapped_server IS NULL"
                ).fetchall():
                    wrapped = _wrap_dek_server(
                        bytes.fromhex(key_hex), email, self._server_kek
                    )
                    conn.execute(
                        "UPDATE users SET dek_wrapped_server = ?, encryption_key = ?"
                        " WHERE id = ?",
                        (wrapped, self._key_shred_value, user_id),
                    )
            self._conn = conn

    def user_exists(self, email: str) -> bool:
        """Return ``True`` if a user with ``email`` is registered.

        The lookup is case-insensitive. Returns ``False`` for unknown users.
        """
        with self._lock:
            conn = self._require_open()
            row = conn.execute("SELECT 1 FROM users WHERE email = ?",(email,),).fetchone()
            return row is not None

    def password_changed_at(self, email: str) -> Optional[str]:
        """Return the UTC timestamp of the last password change for ``email``.

        The value is set at registration and bumped by every successful
        :meth:`change_password` and :meth:`reset_password` call, so it can
        serve as a session epoch: any change invalidates previously issued
        sessions. Returns ``None`` for unknown users.
        """
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT password_changed_at FROM users WHERE email = ?",
                (self._normalize_email(email),),
            ).fetchone()
        return row[0] if row is not None else None

    def create_user(
        self,
        email: str,
        password: str,
        display_name: str,
        terms_version: str,
        key_mode: str = "server",
    ) -> int:
        """Register a new user and return the new user's id (``int``).

        ``email`` is normalized to lowercase; ``display_name`` is stripped of
        surrounding whitespace. The password is stored only as a salted
        Argon2id hash — never in plaintext. A cryptographically secure random
        32-byte per-user DEK is generated once and stored only wrapped
        (AES-256-GCM) according to ``key_mode``:

        - ``"server"`` (default): wrapped under the server KEK in
          ``dek_wrapped_server``; :meth:`get_encryption_key` releases the DEK
          after password verification and password reset stays possible.
          Requires a configured server KEK.
        - ``"private"``: wrapped under a password-derived (Argon2id) KEK in
          ``dek_wrapped_private`` (Posteo-style zero-access: the server cannot
          unwrap it); :meth:`get_private_encryption_key` releases the DEK and
          :meth:`reset_password` is refused for the account.
        - ``"both"``: both wraps of the same DEK are stored; both getters
          return it and password reset is refused.

        The legacy ``encryption_key`` column is not used for new users (it is
        set to ``NULL``/``''``). ``terms_version`` records which version of
        the terms and conditions (AGB) the user accepted; the acceptance is
        stored in the same transaction as the user row.

        Raises
        ------
        ValueError
            If the e-mail is malformed, the password is empty/whitespace-only,
            the display name is empty/whitespace-only, ``terms_version`` is
            empty, ``key_mode`` is unknown, or a server mode is requested but
            no server KEK is configured.
        UserAlreadyExistsError
            If the e-mail is already registered (case-insensitive).
        """
        email = self._normalize_email(email)
        self._validate_email(email)

        if self.user_exists(email):
            raise UserAlreadyExistsError(f"User {email} is already registered!")

        if not password or not password.strip():
            raise ValueError("password must not be empty")
        policy_error = password_policy_error(password)
        if policy_error:
            raise ValueError(policy_error)
        display_name = display_name.strip()
        if not display_name:
            raise ValueError("display_name must not be empty")
        if not terms_version or not terms_version.strip():
            raise ValueError("terms_version must not be empty")
        terms_version = terms_version.strip()
        if key_mode not in KEY_MODES:
            raise ValueError(f"key_mode must be one of {KEY_MODES}")
        dek = secrets.token_bytes(32)
        wrapped_server = None
        wrapped_private = None
        if key_mode in ("server", "both"):
            if self._server_kek is None:
                raise ValueError(
                    "key_mode 'server'/'both' requires a server KEK: pass "
                    f"server_kek=... to UserRegistry or set {SERVER_KEK_ENV_VAR}"
                )
            wrapped_server = _wrap_dek_server(dek, email, self._server_kek)
        if key_mode in ("private", "both"):
            wrapped_private = _wrap_dek_private(dek, password, email)
        pw_hash = _hasher.hash(password)
        now = _utc_now()
        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                cursor = conn.execute(
                    "INSERT INTO users (email, display_name, password_hash,"
                    " encryption_key, key_mode, dek_wrapped_server,"
                    " dek_wrapped_private, created_at, updated_at,"
                    " password_changed_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        email,
                        display_name,
                        pw_hash,
                        self._key_shred_value,
                        key_mode,
                        wrapped_server,
                        wrapped_private,
                        now,
                        now,
                        now,
                    ),
                )
                user_id = cursor.lastrowid
                conn.execute(
                    "INSERT INTO terms_acceptances (user_id, terms_version,"
                    " accepted_at) VALUES (?, ?, ?)",
                    (user_id, terms_version, now),
                )
                conn.execute("COMMIT")
            except sqlite3.IntegrityError:
                conn.execute("ROLLBACK")
                raise UserAlreadyExistsError(
                    f"user already registered: {email}"
                ) from None
        self._logger.info(
            "create_user email=%s id=%s terms_version=%s", email, user_id, terms_version
        )
        return user_id

    def get_terms_acceptance(self, email: str) -> Optional[dict]:
        """Return the latest AGB acceptance for ``email``.

        Returns ``{"terms_version": str, "accepted_at": str}`` or ``None``
        if the user does not exist or never accepted the terms.
        """
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT ta.terms_version, ta.accepted_at FROM terms_acceptances ta"
                " JOIN users u ON u.id = ta.user_id WHERE u.email = ?"
                " ORDER BY ta.id DESC LIMIT 1",
                (self._normalize_email(email),),
            ).fetchone()
        if row is None:
            return None
        return {"terms_version": row[0], "accepted_at": row[1]}

    def _get_key_row(self, email: str):
        with self._lock:
            conn = self._require_open()
            return conn.execute(
                "SELECT password_hash, encryption_key, dek_wrapped_server,"
                " dek_wrapped_private FROM users WHERE email = ?",
                (self._normalize_email(email),),
            ).fetchone()

    def _verify_key_row_password(self, row, password: str) -> bool:
        if row is None:
            try:
                _hasher.verify(_DUMMY_HASH, password)
            except _VERIFY_ERRORS:
                pass
            return False
        try:
            return _hasher.verify(row[0], password)
        except _VERIFY_ERRORS:
            return False

    def get_encryption_key(self, email: str, password: str) -> Optional[bytes]:
        """Return the user's DEK via the server-KEK path of ``email``.

        This is the **resettable** encryption path (``key_mode="server"``,
        the default). The 32-byte DEK is generated once at registration and
        stored only wrapped under the server KEK (``dek_wrapped_server``,
        AES-256-GCM). The password is verified against the stored Argon2id
        hash first; only a correct password releases the DEK, which can
        encrypt and decrypt the user's data files.

        Because the wrap does not depend on the password, the DEK stays the
        same across password changes and token-based password resets. Anyone
        who can reach the server KEK (``server_kek`` / ``USER_REGISTRY_SERVER_KEK``)
        can unwrap the DEK — a database leak alone only yields the wrapped
        DEK. Accounts created with ``key_mode="private"`` have no server wrap
        and ``None`` is returned for them (use :meth:`get_private_encryption_key`).
        Legacy databases that still hold a plaintext ``encryption_key`` (no
        server KEK was configured at :meth:`init_db` time) return that key
        directly.

        Returns ``None`` if the user does not exist or the password is
        wrong, so no key is released for an unauthenticated caller. The
        e-mail lookup is case-insensitive. The key is never written to the
        log file.

        Raises
        ------
        RuntimeError
            If a server wrap exists but no server KEK is configured, or the
            configured KEK does not match / the envelope fails its integrity
            check.
        """
        email = self._normalize_email(email)
        row = self._get_key_row(email)
        if not self._verify_key_row_password(row, password):
            return None
        if row[2] is not None:
            if self._server_kek is None:
                raise RuntimeError(
                    "a server-wrapped DEK exists but no server KEK is configured "
                    f"(pass server_kek=... or set {SERVER_KEK_ENV_VAR})"
                )
            return _unwrap_dek_server(row[2], email, self._server_kek)
        if row[1] not in (None, ""):
            return bytes.fromhex(row[1])
        return None

    def get_private_encryption_key(self, email: str, password: str) -> Optional[bytes]:
        """Return the user's DEK via the password-KEK path of ``email``.

        This is the **Posteo-style zero-access** encryption path
        (``key_mode="private"`` or ``"both"``). The 32-byte DEK is wrapped
        (AES-256-GCM) under a KEK derived with Argon2id (memory-hard) from the
        password and a per-user random salt stored in ``dek_wrapped_private``.
        The password is verified against the stored Argon2id hash first; only
        a correct password can derive the KEK and unwrap the DEK. A database
        leak alone therefore does not reveal the DEK — an attacker still has
        to brute-force the password.

        Difference to :meth:`get_encryption_key`:

        - the DEK is stable across password **changes** (the wrap is re-wrapped
          under the new password by :meth:`change_password`), but a
          token-based password **reset** is impossible for such accounts
          (:meth:`reset_password` raises :class:`PasswordResetNotAllowedError`),
          because without the old password the wrap cannot be re-wrapped;
        - for ``key_mode="both"`` both getters return the same DEK; for
          ``key_mode="server"`` accounts there is no private wrap and ``None``
          is returned.

        Legacy databases that still hold a plaintext ``encryption_key`` fall
        back to the old behavior: a key derived with Argon2id from the
        password and the stored key is returned.

        Returns ``None`` if the user does not exist or the password is
        wrong, so no key is released for an unauthenticated caller. The
        e-mail lookup is case-insensitive. Neither key is written to the
        log file.
        """
        email = self._normalize_email(email)
        row = self._get_key_row(email)
        if not self._verify_key_row_password(row, password):
            return None
        if row[3] is not None:
            return _unwrap_dek_private(row[3], password, email)
        if row[1] not in (None, ""):
            return _derive_key(password, row[1])
        return None

    def create_invitation(self, email: str, expires_in_seconds: int) -> str:
        """Create a single-use invitation for ``email`` and return its token.

        The token is returned once and is never stored; only its SHA-256
        hash is persisted in the ``invitations`` table, together with the
        normalized e-mail address the invitation is bound to and the expiry
        timestamp. The token never appears in the log file.

        Raises
        ------
        ValueError
            If the e-mail is malformed or ``expires_in_seconds`` is not
            a positive integer.
        """
        email = self._normalize_email(email)
        self._validate_email(email)
        if not isinstance(expires_in_seconds, int) or expires_in_seconds < 1:
            raise ValueError("expires_in_seconds must be a positive integer")
        token = secrets.token_urlsafe(32)
        now = datetime.now(timezone.utc)
        expires_at = (now + timedelta(seconds=expires_in_seconds)).isoformat(
            timespec="microseconds"
        )

        if self.user_exists(email):
            raise UserAlreadyExistsError(f"User {email} is already registered!")

        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                conn.execute(
                    "INSERT INTO invitations (token_hash, email, created_at,"
                    " expires_at) VALUES (?, ?, ?, ?)",
                    (_token_hash(token), email, now.isoformat(), expires_at),
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
        self._logger.info(
            "create_invitation email=%s expires_at=%s", email, expires_at
        )
        return token

    def invitation_valid(self, token: str, email: str) -> bool:
        """Return ``True`` if ``token`` is an unused, unexpired invitation for ``email``.

        The e-mail comparison is case-insensitive. Returns ``False`` for
        unknown tokens, already-used or expired invitations and for a
        mismatching e-mail address.
        """
        if not token:
            return False
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT email, expires_at, used_at FROM invitations"
                " WHERE token_hash = ?",
                (_token_hash(token),),
            ).fetchone()
        if row is None or row[2] is not None:
            return False
        if row[0] != self._normalize_email(email):
            return False
        if datetime.fromisoformat(row[1]) <= datetime.now(timezone.utc):
            return False
        return True

    def invitation_token_valid(self, token: str) -> bool:
        """Return ``True`` if ``token`` is an unused, unexpired invitation token.

        Unlike :meth:`invitation_valid` this does not check the e-mail
        binding, so it can be used to gate pages that only receive the token
        (e.g. ``/register?invite=<token>``). Returns ``False`` for unknown,
        already-used or expired tokens.
        """
        if not token:
            return False
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT expires_at, used_at FROM invitations WHERE token_hash = ?",
                (_token_hash(token),),
            ).fetchone()
        if row is None or row[1] is not None:
            return False
        if datetime.fromisoformat(row[0]) <= datetime.now(timezone.utc):
            return False
        return True

    def invitation_email(self, token: str) -> Optional[str]:
        """Return the e-mail address a valid invitation ``token`` is bound to.

        Returns the normalized e-mail address if ``token`` is an unused,
        unexpired invitation token, otherwise ``None``.
        """
        if not token:
            return None
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT email, expires_at, used_at FROM invitations"
                " WHERE token_hash = ?",
                (_token_hash(token),),
            ).fetchone()
        if row is None or row[2] is not None:
            return None
        if datetime.fromisoformat(row[1]) <= datetime.now(timezone.utc):
            return None
        return row[0]


    def consume_invitation(self, token: str, email: str) -> bool:
        """Mark the invitation ``token`` as used; return ``True`` if it was valid.

        The check and the update run in a single ``BEGIN IMMEDIATE``
        transaction, so a single-use invitation can never be consumed twice,
        even under concurrency. Returns ``False`` if the token is unknown,
        already used, expired or bound to a different e-mail address.
        """
        if not token:
            return False
        now = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                cursor = conn.execute(
                    "UPDATE invitations SET used_at = ? WHERE token_hash = ?"
                    " AND email = ? AND used_at IS NULL AND expires_at > ?",
                    (now, _token_hash(token), self._normalize_email(email), now),
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
            consumed = cursor.rowcount > 0
        if consumed:
            self._logger.info(
                "consume_invitation email=%s", self._normalize_email(email)
            )
        return consumed

    def create_password_reset(self, email: str, expires_in_seconds: int) -> Optional[str]:
        """Create a single-use password-reset token for ``email``; return it.

        Returns ``None`` if no user with ``email`` is registered, so callers
        can answer uniformly without revealing whether an account exists.
        The token is returned once and is never stored; only its SHA-256 hash
        is persisted in the ``password_resets`` table together with the
        normalized e-mail address and the expiry timestamp. The token never
        appears in the log file.

        Raises
        ------
        ValueError
            If the e-mail is malformed or ``expires_in_seconds`` is not
            a positive integer.
        """
        email = self._normalize_email(email)
        self._validate_email(email)
        if not isinstance(expires_in_seconds, int) or expires_in_seconds < 1:
            raise ValueError("expires_in_seconds must be a positive integer")

        if not self.user_exists(email):
            raise ValueError(f"User {email} is not registered")

        token = secrets.token_urlsafe(32)
        now = datetime.now(timezone.utc)
        expires_at = (now + timedelta(seconds=expires_in_seconds)).isoformat(
            timespec="microseconds"
        )

        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                conn.execute(
                    "INSERT INTO password_resets (token_hash, email, created_at,"
                    " expires_at) VALUES (?, ?, ?, ?)",
                    (_token_hash(token), email, now.isoformat(), expires_at),
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
        self._logger.info(
            "create_password_reset email=%s expires_at=%s", email, expires_at
        )
        return token

    def password_reset_valid(self, token: str) -> bool:
        """Return ``True`` if ``token`` is an unused, unexpired password-reset token.

        Returns ``False`` for unknown, already-used or expired tokens.
        """
        if not token:
            return False
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT expires_at, used_at FROM password_resets WHERE token_hash = ?",
                (_token_hash(token),),
            ).fetchone()
        if row is None or row[1] is not None:
            return False
        if datetime.fromisoformat(row[0]) <= datetime.now(timezone.utc):
            return False
        return True

    def password_reset_email(self, token: str) -> Optional[str]:
        """Return the e-mail address a valid reset ``token`` is bound to.

        Returns the normalized e-mail address if ``token`` is an unused,
        unexpired password-reset token, otherwise ``None``.
        """
        if not token:
            return None
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT email, expires_at, used_at FROM password_resets"
                " WHERE token_hash = ?",
                (_token_hash(token),),
            ).fetchone()
        if row is None or row[2] is not None:
            return None
        if datetime.fromisoformat(row[1]) <= datetime.now(timezone.utc):
            return None
        return row[0]

    def reset_password(
        self, token: str, new_password: str, allow_data_loss: bool = False
    ) -> bool:
        """Set a new password using a single-use reset ``token``; return ``True`` on success.

        The token check, the password update and the token consumption run
        in a single ``BEGIN IMMEDIATE`` transaction, so a reset token can
        never be used twice, even under concurrency. Returns ``False`` if the
        token is unknown, already used or expired; the stored password is
        left unchanged in that case.

        For accounts whose DEK is wrapped under the password-derived KEK
        (``key_mode="private"`` or ``"both"``) a token-based reset is refused
        with :class:`PasswordResetNotAllowedError` and the token stays valid:
        without the old password the wrapped DEK cannot be re-wrapped, so the
        user's encrypted data would become unreadable. Pass
        ``allow_data_loss=True`` to reset anyway (the data stays encrypted
        under the old password), or use :meth:`change_password`, which
        re-wraps the DEK under the new password and keeps the data readable.

        Raises
        ------
        ValueError
            If ``new_password`` is empty/whitespace-only or violates the
            password policy.
        PasswordResetNotAllowedError
            If the account has a password-wrapped DEK and ``allow_data_loss``
            is false.
        """
        if not new_password or not new_password.strip():
            raise ValueError("new_password must not be empty")
        policy_error = password_policy_error(new_password)
        if policy_error:
            raise ValueError(policy_error)
        if not token:
            return False
        now = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                row = conn.execute(
                    "SELECT email, expires_at, used_at FROM password_resets"
                    " WHERE token_hash = ?",
                    (_token_hash(token),),
                ).fetchone()
                if (
                    row is None
                    or row[2] is not None
                    or datetime.fromisoformat(row[1]) <= datetime.now(timezone.utc)
                ):
                    conn.execute("ROLLBACK")
                    return False
                email = row[0]
                if not allow_data_loss:
                    (wrapped_private,) = conn.execute(
                        "SELECT dek_wrapped_private FROM users WHERE email = ?",
                        (email,),
                    ).fetchone()
                    if wrapped_private is not None:
                        conn.execute("ROLLBACK")
                        raise PasswordResetNotAllowedError(
                            f"password reset is not possible for {email}: the DEK is "
                            "wrapped under the password-derived KEK and would become "
                            "undecryptable; use change_password instead, or pass "
                            "allow_data_loss=True"
                        )
                changed_at = _utc_now()
                conn.execute(
                    "UPDATE users SET password_hash = ?, updated_at = ?,"
                    " password_changed_at = ? WHERE email = ?",
                    (_hasher.hash(new_password), changed_at, changed_at, email),
                )
                conn.execute(
                    "UPDATE password_resets SET used_at = ? WHERE token_hash = ?",
                    (now, _token_hash(token)),
                )
                conn.execute("COMMIT")
            except PasswordResetNotAllowedError:
                raise
            except Exception:
                conn.execute("ROLLBACK")
                raise
        self._logger.info("reset_password email=%s", email)
        return True

    def verify_password(self, email: str, password: str) -> bool:
        """Return ``True`` if ``password`` is correct for the user ``email``.

        Returns ``False`` both for wrong passwords and for unknown users.
        Password comparison is case-sensitive; e-mail lookup is not.
        """
        with self._lock:
            conn = self._require_open()
            row = conn.execute(
                "SELECT password_hash FROM users WHERE email = ?",
                (self._normalize_email(email),),
            ).fetchone()
        if row is None:
            try:
                _hasher.verify(_DUMMY_HASH, password)
            except _VERIFY_ERRORS:
                pass
            return False
        try:
            return _hasher.verify(row[0], password)
        except _VERIFY_ERRORS:
            return False

    def change_password(self, email: str, old_password: str, new_password: str) -> bool:
        """Change the password of user ``email``; return ``True`` on success.

        Returns ``False`` if the user does not exist or ``old_password`` is
        wrong; in that case the stored password is left unchanged. All
        outstanding password-reset tokens of the user are invalidated in
        the same transaction. If the account has a password-wrapped DEK
        (``key_mode="private"`` or ``"both"``), the DEK is re-wrapped under
        the new password in the same transaction, so data encrypted with it
        stays readable after the change.

        Raises
        ------
        ValueError
            If ``new_password`` is empty/whitespace-only or violates the
            password policy.
        """
        if not new_password or not new_password.strip():
            raise ValueError("new_password must not be empty")
        policy_error = password_policy_error(new_password)
        if policy_error:
            raise ValueError(policy_error)
        email = self._normalize_email(email)
        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                row = conn.execute(
                    "SELECT password_hash FROM users WHERE email = ?", (email,)
                ).fetchone()
                if row is None:
                    conn.execute("ROLLBACK")
                    return False
                try:
                    old_ok = _hasher.verify(row[0], old_password)
                except _VERIFY_ERRORS:
                    old_ok = False
                if not old_ok:
                    conn.execute("ROLLBACK")
                    return False
                key_row = conn.execute(
                    "SELECT encryption_key, dek_wrapped_server, dek_wrapped_private"
                    " FROM users WHERE email = ?",
                    (email,),
                ).fetchone()
                new_wrapped_private = key_row[2]
                if key_row[2] is not None:
                    dek = _unwrap_dek_private(key_row[2], old_password, email)
                    new_wrapped_private = _wrap_dek_private(dek, new_password, email)
                elif (
                    key_row[0] not in (None, "")
                    and key_row[1] is None
                    and self._server_kek is not None
                ):
                    wrapped = _wrap_dek_server(
                        bytes.fromhex(key_row[0]), email, self._server_kek
                    )
                    conn.execute(
                        "UPDATE users SET dek_wrapped_server = ?, encryption_key = ?"
                        " WHERE email = ?",
                        (wrapped, self._key_shred_value, email),
                    )
                changed_at = _utc_now()
                conn.execute(
                    "UPDATE users SET password_hash = ?, updated_at = ?,"
                    " password_changed_at = ?, dek_wrapped_private = ? WHERE email = ?",
                    (
                        _hasher.hash(new_password),
                        changed_at,
                        changed_at,
                        new_wrapped_private,
                        email,
                    ),
                )
                conn.execute(
                    "DELETE FROM password_resets WHERE email = ?", (email,)
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
        self._logger.info("change_password email=%s", email)
        return True

    def delete_user(self, email: str) -> bool:
        """Delete the user ``email``; return ``True`` if a user was deleted.

        Returns ``False`` if no such user exists (the call is then a no-op).
        After deletion the e-mail address may be registered again. All
        outstanding password-reset tokens of the user are deleted in the
        same transaction, so a token minted before the deletion cannot be
        used on a later account registered under the same e-mail address.
        """
        email = self._normalize_email(email)
        with self._lock:
            conn = self._require_open()
            conn.execute("BEGIN IMMEDIATE")
            try:
                cursor = conn.execute(
                    "DELETE FROM users WHERE email = ?", (email,)
                )
                conn.execute(
                    "DELETE FROM password_resets WHERE email = ?", (email,)
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
            deleted = cursor.rowcount > 0
        if deleted:
            self._logger.info("delete_user email=%s", email)
        return deleted

    def close(self) -> None:
        """Close the database connection and the log file. Idempotent."""
        with self._lock:
            if self._conn is not None:
                self._conn.close()
                self._conn = None
            if self._handler is not None:
                self._logger.removeHandler(self._handler)
                self._handler.close()
                self._handler = None

    def __enter__(self) -> "UserRegistry":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
