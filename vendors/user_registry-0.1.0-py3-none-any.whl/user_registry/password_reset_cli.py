"""Command-line interface of the core package: create password-reset links.

Installed as the ``create-password-reset`` console script; also runnable via
``python -m user_registry.password_reset_cli``. The
``scripts/create_password_reset.py`` wrapper in the repository calls
:func:`main`.
"""

from __future__ import annotations

import argparse
import sys
from typing import Optional

from . import UserRegistry


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="create-password-reset",
        description="Create a single-use password-reset (magic) link for the "
        "user_registry web UI.",
    )
    parser.add_argument("--db", required=True, help="path to the SQLite database file")
    parser.add_argument(
        "--base-url",
        required=True,
        help="public base URL of the mounted auth UI, e.g. https://example.com/auth",
    )
    parser.add_argument(
        "--email", required=True, help="e-mail address of the existing user"
    )
    parser.add_argument(
        "--expires-in-days",
        type=int,
        default=1,
        help="validity of the reset link in days (default: 1)",
    )
    args = parser.parse_args(argv)

    if args.expires_in_days < 1:
        parser.error("--expires-in-days must be at least 1")

    registry = UserRegistry(args.db)
    registry.init_db()
    try:
        token = registry.create_password_reset(
            args.email, expires_in_seconds=args.expires_in_days * 24 * 3600
        )
    finally:
        registry.close()

    if token is None:
        print(f"no registered user with e-mail: {args.email}", file=sys.stderr)
        return 1

    base_url = args.base_url.rstrip("/")
    print(f"{base_url}/reset-password?token={token}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
