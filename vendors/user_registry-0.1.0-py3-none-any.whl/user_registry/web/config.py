from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from user_registry import UserRegistry


@dataclass
class AuthConfig:
    registry: UserRegistry
    secret_key: str
    prefix: str = "/auth"
    terms_version: str = "1.0"
    terms_document: Optional[str] = None
    imprint_document: Optional[str] = None
    background_image: Optional[str] = None
    require_reaccept: bool = False
    require_invitation: bool = False
    login_redirect: Optional[str] = None
    session_cookie: str = "auth_session"
    csrf_cookie: str = "auth_csrf"
    session_max_age: int = 7 * 24 * 3600
    cookie_secure: bool = True
    login_max_attempts_per_day: int = 10
