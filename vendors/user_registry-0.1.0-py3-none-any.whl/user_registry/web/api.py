from __future__ import annotations

import threading
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from user_registry import UserAlreadyExistsError

from .config import AuthConfig
from .security import csrf_valid, make_serializer, read_session, sign_session


class RegisterIn(BaseModel):
    email: str
    password: str
    confirm_password: str
    display_name: str
    accepted_terms: bool
    invite: Optional[str] = None


class LoginIn(BaseModel):
    email: str
    password: str


class ChangePasswordIn(BaseModel):
    old_password: str
    new_password: str


class DeleteIn(BaseModel):
    password: str


class ResetPasswordIn(BaseModel):
    token: str
    email: str
    new_password: str
    confirm_new_password: str


def create_api_router(config: AuthConfig) -> APIRouter:
    router = APIRouter(tags=["auth-api"])
    serializer = make_serializer(config)

    login_failures: dict = {}
    failures_lock = threading.Lock()

    def _today() -> str:
        return datetime.now(timezone.utc).date().isoformat()

    def _login_throttled(email: str) -> bool:
        with failures_lock:
            day, count = login_failures.get(email, ("", 0))
            return day == _today() and count >= config.login_max_attempts_per_day

    def _record_login_failure(email: str) -> None:
        today = _today()
        with failures_lock:
            day, count = login_failures.get(email, (today, 0))
            login_failures[email] = (today, count + 1 if day == today else 1)

    def _clear_login_failures(email: str) -> None:
        with failures_lock:
            login_failures.pop(email, None)

    def set_session(resp: Response, email: str) -> None:
        resp.set_cookie(
            config.session_cookie,
            sign_session(config, serializer, email),
            max_age=config.session_max_age,
            httponly=True,
            samesite="lax",
            secure=config.cookie_secure,
        )

    def current_email(request: Request) -> str:
        email = read_session(request, config, serializer)
        if email is None or not config.registry.user_exists(email):
            raise HTTPException(status_code=401, detail="not authenticated")
        if config.require_reaccept:
            acceptance = config.registry.get_terms_acceptance(email)
            if acceptance is None or acceptance["terms_version"] != config.terms_version:
                raise HTTPException(
                    status_code=403, detail="terms re-acceptance required"
                )
        return email

    def require_csrf(request: Request) -> None:
        if not csrf_valid(request, config):
            raise HTTPException(status_code=403, detail="csrf token mismatch")

    @router.post("/register", dependencies=[Depends(require_csrf)])
    def register(payload: RegisterIn) -> Response:
        if not payload.accepted_terms:
            raise HTTPException(
                status_code=422, detail="terms and conditions must be accepted"
            )
        if payload.password != payload.confirm_password:
            raise HTTPException(
                status_code=422, detail="Password does not match the confirmation password"
            )
        if config.require_invitation:
            if not payload.invite:
                raise HTTPException(
                    status_code=403, detail="invitation token is required"
                )
            if not config.registry.invitation_token_valid(payload.invite):
                raise HTTPException(
                    status_code=403, detail="invalid or expired invitation token"
                )
            if not config.registry.invitation_valid(payload.invite, payload.email):
                # Get the expected email for a better error message
                expected_email = config.registry.invitation_email(payload.invite)
                if expected_email:
                    raise HTTPException(
                        status_code=403, 
                        detail=f"This invitation is bound to {expected_email}. Please use that email address."
                    )
                else:
                    raise HTTPException(
                        status_code=403, detail="invitation token is bound to a different email address"
                    )
        try:
            user_id = config.registry.create_user(
                payload.email, payload.password, payload.display_name, config.terms_version
            )
        except UserAlreadyExistsError:
            raise HTTPException(status_code=409, detail="email already registered") from None
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from None
        if config.require_invitation:
            config.registry.consume_invitation(payload.invite, payload.email)
        resp = JSONResponse(
            {"ok": True, "id": user_id, "email": payload.email.strip().lower()}
        )
        set_session(resp, payload.email)
        return resp

    @router.post("/login", dependencies=[Depends(require_csrf)])
    def login(payload: LoginIn) -> Response:
        email = payload.email.strip().lower()
        if _login_throttled(email):
            raise HTTPException(
                status_code=429,
                detail="too many failed login attempts; try again tomorrow",
            )
        if not config.registry.verify_password(payload.email, payload.password):
            _record_login_failure(email)
            raise HTTPException(status_code=401, detail="invalid credentials")
        _clear_login_failures(email)
        resp = JSONResponse({"ok": True, "email": email})
        set_session(resp, payload.email)
        return resp

    @router.post("/logout", dependencies=[Depends(require_csrf)])
    def logout() -> Response:
        resp = JSONResponse({"ok": True})
        resp.delete_cookie(config.session_cookie)
        return resp

    @router.get("/me")
    def me(email: str = Depends(current_email)) -> dict:
        acceptance = config.registry.get_terms_acceptance(email)
        return {
            "email": email,
            "terms_version": acceptance["terms_version"] if acceptance else None,
        }

    @router.post("/change-password", dependencies=[Depends(require_csrf)])
    def change_password(
        payload: ChangePasswordIn, email: str = Depends(current_email)
    ) -> Response:
        try:
            changed = config.registry.change_password(
                email, payload.old_password, payload.new_password
            )
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from None
        if not changed:
            raise HTTPException(status_code=401, detail="wrong current password")
        resp = JSONResponse({"ok": True})
        resp.delete_cookie(config.session_cookie)
        return resp

    @router.post("/delete", dependencies=[Depends(require_csrf)])
    def delete(payload: DeleteIn, email: str = Depends(current_email)) -> Response:
        if not config.registry.verify_password(email, payload.password):
            raise HTTPException(status_code=401, detail="wrong password")
        config.registry.delete_user(email)
        resp = JSONResponse({"ok": True})
        resp.delete_cookie(config.session_cookie)
        return resp

    @router.get("/user-exists")
    def user_exists(email: str) -> dict:
        """Always answers ``{"exists": true}`` so the endpoint cannot be
        used to enumerate registered accounts."""
        return {"exists": True}

    @router.get("/invitation-email")
    def get_invitation_email(token: str) -> dict:
        email = config.registry.invitation_email(token)
        if email is None:
            raise HTTPException(status_code=404, detail="invitation not found or expired")
        return {"email": email}


    @router.post("/reset-password", dependencies=[Depends(require_csrf)])
    def reset_password(payload: ResetPasswordIn) -> Response:
        token_email = config.registry.password_reset_email(payload.token)
        if token_email is None or token_email != payload.email.strip().lower():
            raise HTTPException(status_code=400, detail="invalid or expired token")
        if payload.new_password != payload.confirm_new_password:
            raise HTTPException(status_code=401, detail="Password does not match the confirmation password")
        try:
            ok = config.registry.reset_password(payload.token, payload.new_password)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from None
        if not ok:
            raise HTTPException(status_code=400, detail="invalid or expired token")
        resp = JSONResponse({"ok": True})
        resp.delete_cookie(config.session_cookie)
        return resp

    return router
