"""Optional FastAPI web UI for the user_registry core.

Plug into any FastAPI app::

    from fastapi import FastAPI
    from user_registry import UserRegistry
    from user_registry.web import mount_auth

    app = FastAPI()
    registry = UserRegistry("users.db")
    registry.init_db()
    mount_auth(
        app,
        registry,
        prefix="/auth",
        secret_key="change-me",
        terms={"version": "2025-01", "document": "docs/my-agb.html"},
        imprint={"document": "docs/impressum.html"},
    )

``terms["document"]`` / ``imprint["document"]`` may be a file path, a raw
HTML string, or an absolute URL (the page then redirects to it). When omitted,
bundled default documents are served. Requires the ``web`` extra:
``pip install user-registry[web]``.
"""

from __future__ import annotations

import os
from typing import Optional

from fastapi import APIRouter, FastAPI, Request

from user_registry import UserRegistry

from .api import create_api_router
from .config import AuthConfig
from .pages import create_pages_router

__all__ = ["AuthConfig", "mount_auth"]

SECRET_ENV_VAR = "USER_REGISTRY_SECRET_KEY"

_FORBIDDEN_SECRETS = {"", "change-me-in-production"}

_SECRET_ERROR = (
    "mount_auth requires a strong secret_key to sign session cookies; refusing "
    "to start with a missing, empty or well-known default secret. Generate one "
    "and provide it via the environment or a secrets manager, e.g.:\n"
    '  export USER_REGISTRY_SECRET_KEY=$(python -c "import secrets; '
    'print(secrets.token_hex(32))")\n'
    "then call mount_auth without secret_key (it reads "
    f"{SECRET_ENV_VAR}), or pass secret_key explicitly."
)


def _resolve_secret_key(secret_key: Optional[str]) -> str:
    if secret_key is None:
        secret_key = os.environ.get(SECRET_ENV_VAR)
    if not secret_key or secret_key in _FORBIDDEN_SECRETS:
        raise ValueError(_SECRET_ERROR)
    return secret_key


def mount_auth(
    app: FastAPI,
    registry: UserRegistry,
    prefix: str = "/auth",
    *,
    secret_key: Optional[str] = None,
    terms: Optional[dict] = None,
    imprint: Optional[dict] = None,
    background_image: Optional[str] = None,
    require_reaccept: bool = False,
    require_invitation: bool = False,
    login_redirect: Optional[str] = None,
    session_cookie: str = "auth_session",
    csrf_cookie: str = "auth_csrf",
    session_max_age: int = 7 * 24 * 3600,
    cookie_secure: bool = True,
    login_max_attempts_per_day: int = 10,
) -> tuple[APIRouter, AuthConfig]:
    """Mount the authentication pages and JSON API onto ``app``.

    ``secret_key`` signs the session cookies. If omitted, it is read from
    the ``USER_REGISTRY_SECRET_KEY`` environment variable (use a secrets
    manager in production). A missing, empty or well-known default secret
    (``"change-me-in-production"``) raises ``ValueError`` with instructions,
    because session cookies signed with it can be forged.

    Returns ``(root, config)``: the mounted router and its ``AuthConfig``.

    Pages: ``<prefix>/register``, ``/login``, ``/forgot-password``,
    ``/reset-password``, ``/change-password``, ``/delete``,
    ``/terms`` (AGB), ``/impressum``.
    API: ``<prefix>/api/register``, ``/login``, ``/logout``, ``/me``,
    ``/change-password``, ``/delete``, ``/user-exists``,
    ``/reset-password``.

    ``terms`` is a dict with keys ``version`` (recorded on registration) and
    ``document`` (custom AGB: file path, HTML string, or URL). ``imprint`` is
    a dict with key ``document`` (same flexibility). ``background_image`` is an
    optional image shown behind all pages: an absolute URL, a path served by
    your app (starting with ``/``), or a local file path (served by the auth
    router itself). When
    ``require_reaccept`` is true, sessions whose recorded AGB version differs
    from ``terms["version"]`` are treated as unauthenticated on protected
    routes. When ``require_invitation`` is true, registration additionally
    requires a valid single-use invitation token (see
    ``UserRegistry.create_invitation``) bound to the registering e-mail, and
    the register page itself is only served for a valid
    ``<prefix>/register?invite=<token>`` link (otherwise it redirects to the
    login page); invitation links have the shape
    ``<prefix>/register?invite=<token>``.
    ``login_redirect`` is the URL the login page navigates to after a
    successful login (absolute URL or app path); defaults to
    ``<prefix>/change-password``.

    "Passwort vergessen" (``<prefix>/forgot-password``) is an info page
    telling the user to contact the support e-mail address. Password-reset
    magic links are generated offline with the ``create-password-reset``
    console script (``scripts/create_password_reset.py``) and point to
    ``<prefix>/reset-password?token=<token>``; that page shows a form
    (e-mail, old password, new password, confirmation) and
    ``POST <prefix>/api/reset-password`` validates token, e-mail binding and
    old password before setting the new one (single-use). The pages contain
    no registration link; on the login page, "Passwort vergessen" /
    "Passwort ändern" are shown in the footer as soon
    as the entered e-mail belongs to an existing user.
    """
    secret_key = _resolve_secret_key(secret_key)
    terms = terms or {}
    imprint = imprint or {}
    prefix = "/" + prefix.strip("/")
    config = AuthConfig(
        registry=registry,
        secret_key=secret_key,
        prefix=prefix,
        terms_version=str(terms.get("version", "1.0")),
        terms_document=terms.get("document"),
        imprint_document=imprint.get("document"),
        background_image=background_image,
        require_reaccept=require_reaccept,
        require_invitation=require_invitation,
        login_redirect=login_redirect,
        session_cookie=session_cookie,
        csrf_cookie=csrf_cookie,
        session_max_age=session_max_age,
        cookie_secure=cookie_secure,
        login_max_attempts_per_day=login_max_attempts_per_day,
    )

    @app.middleware("http")
    async def _security_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Content-Security-Policy"] = "frame-ancestors 'none'"
        return response

    root = APIRouter(prefix=prefix)
    root.include_router(create_api_router(config), prefix="/api")
    root.include_router(create_pages_router(config))
    app.include_router(root)
    return root, config
