// Password input abstraction - shared behavior for all password fields

// Color the input frame while typing: red when invalid, green when valid
function setPasswordFrameState(input, state) {
  input.classList.toggle('password-invalid', state === 'invalid');
  input.classList.toggle('password-valid', state === 'valid');
}

// Live validation: policy on the password field, match on the confirmation field
function attachPasswordLiveValidation(passwordInput, confirmInput) {
  const update = () => {
    if (!passwordInput.value) {
      setPasswordFrameState(passwordInput, 'neutral');
    } else {
      setPasswordFrameState(
        passwordInput,
        passwordPolicyError(passwordInput.value) ? 'invalid' : 'valid'
      );
    }
    if (confirmInput) {
      if (!confirmInput.value) {
        setPasswordFrameState(confirmInput, 'neutral');
      } else {
        setPasswordFrameState(
          confirmInput,
          confirmInput.value === passwordInput.value ? 'valid' : 'invalid'
        );
      }
    }
  };
  passwordInput.addEventListener('input', update);
  if (confirmInput) {
    confirmInput.addEventListener('input', update);
  }
  update();
}

// Function to create a password input field
function createPasswordInput(name, labelText, testId = null, showHint = true) {
  const container = document.createElement('div');
  container.className = 'password-field-container';
  
  const label = document.createElement('label');
  label.className = 'password-field';
  
  const span = document.createElement('span');
  span.className = 'password-label';
  span.textContent = labelText;
  
  const input = document.createElement('input');
  input.type = 'password';
  input.name = name;
  input.className = 'password-input';
  input.required = true;
  if (testId) {
    input.setAttribute('data-testid', testId);
  }
  
  label.appendChild(span);
  label.appendChild(input);
  container.appendChild(label);
  
  if (showHint) {
    const hint = document.createElement('p');
    hint.className = 'password-hint hint';
    hint.textContent = 'Mindestens 8 Zeichen, ein Großbuchstabe, ein Kleinbuchstabe, eine Zahl und ein Sonderzeichen (-_!?=+.-).';
    container.appendChild(hint);
  }

  attachPasswordLiveValidation(input, null);

  return container;
}

// Function to create password input with confirmation
function createPasswordInputWithConfirmation(newPasswordName, confirmPasswordName, newLabelText, confirmLabelText, newTestId = null, confirmTestId = null) {
  const container = document.createElement('div');
  container.className = 'password-field-container';
  
  // New password field
  const newLabel = document.createElement('label');
  newLabel.className = 'password-field';
  
  const newSpan = document.createElement('span');
  newSpan.className = 'password-label';
  newSpan.textContent = newLabelText;
  
  const newInput = document.createElement('input');
  newInput.type = 'password';
  newInput.name = newPasswordName;
  newInput.className = 'password-input new-password';
  newInput.required = true;
  if (newTestId) {
    newInput.setAttribute('data-testid', newTestId);
  }
  
  newLabel.appendChild(newSpan);
  newLabel.appendChild(newInput);
  container.appendChild(newLabel);
  
  // Confirm password field
  const confirmLabel = document.createElement('label');
  confirmLabel.className = 'password-field';
  
  const confirmSpan = document.createElement('span');
  confirmSpan.className = 'password-label';
  confirmSpan.textContent = confirmLabelText;
  
  const confirmInput = document.createElement('input');
  confirmInput.type = 'password';
  confirmInput.name = confirmPasswordName;
  confirmInput.className = 'password-input confirm-password';
  confirmInput.required = true;
  if (confirmTestId) {
    confirmInput.setAttribute('data-testid', confirmTestId);
  }
  
  confirmLabel.appendChild(confirmSpan);
  confirmLabel.appendChild(confirmInput);
  container.appendChild(confirmLabel);
  
  // Password hint
  const hint = document.createElement('p');
  hint.className = 'password-hint hint';
  hint.textContent = 'Mindestens 8 Zeichen, ein Großbuchstabe, ein Kleinbuchstabe, eine Zahl und ein Sonderzeichen (-_!?=+.-).';
  container.appendChild(hint);

  attachPasswordLiveValidation(newInput, confirmInput);

  return container;
}

// Function to validate password fields in a form
function validatePasswordFields(form) {
  const newPasswordInput = form.querySelector('.new-password') || form.querySelector('input[name="password"]');
  const confirmPasswordInput = form.querySelector('.confirm-password');
  
  // Validate password policy if new password field exists
  if (newPasswordInput) {
    const policyError = passwordPolicyError(newPasswordInput.value);
    if (policyError) {
      showError(policyError);
      return false;
    }
  }
  
  // Validate password match if both fields exist
  if (newPasswordInput && confirmPasswordInput) {
    if (newPasswordInput.value !== confirmPasswordInput.value) {
      showError("Die neuen Passw\u00f6rter stimmen nicht \u00fcberein.");
      return false;
    }
  }
  
  return true;
}
