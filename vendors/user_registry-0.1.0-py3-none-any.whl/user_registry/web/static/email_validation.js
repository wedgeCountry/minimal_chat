/**
 * Single client-side source of the e-mail format rules, shared by all auth
 * pages and loadable in Node.js for tests. Mirrors the server-side rules in
 * user_registry/__init__.py (_EMAIL_RE, _MAX_EMAIL_LENGTH): the address is
 * trimmed and lowercased first, must be at most 254 characters and must
 * match ^[^@\s]+@[^@\s]+\.[^@\s]+$. Returns an error message (German, for
 * display in the page) or null if the address is valid.
 */

function emailFormatError(email) {
  const normalized = email.trim().toLowerCase();
  if (normalized.length > 254) {
    return "Die E-Mail-Adresse darf h\u00f6chstens 254 Zeichen lang sein.";
  }
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(normalized)) {
    return "Bitte gib eine g\u00fcltige E-Mail-Adresse ein.";
  }
  return null;
}

// Color the input frame while typing: red when invalid, green when valid,
// using the same classes as the password fields
function setEmailFrameState(input, state) {
  input.classList.toggle('password-invalid', state === 'invalid');
  input.classList.toggle('password-valid', state === 'valid');
}

function updateEmailFrame(input) {
  if (!input.value) {
    setEmailFrameState(input, 'neutral');
  } else {
    setEmailFrameState(input, emailFormatError(input.value) ? 'invalid' : 'valid');
  }
}

// Live validation on the email field
function attachEmailLiveValidation(emailInput) {
  emailInput.addEventListener('input', () => updateEmailFrame(emailInput));
  updateEmailFrame(emailInput);
}

// Function to validate the email field of a form on submit
function validateEmailField(form) {
  const emailInput = form.querySelector('input[name="email"]');
  if (!emailInput) {
    return true;
  }
  const error = emailFormatError(emailInput.value);
  if (error) {
    showError(error);
    return false;
  }
  return true;
}

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { emailFormatError };
}
