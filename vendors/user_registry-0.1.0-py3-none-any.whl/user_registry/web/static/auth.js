async function postJSON(url, data) {
  const res = await fetch(url, {
    method: "POST",
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
      "X-CSRF-Token": window.CSRF_TOKEN || "",
    },
    body: JSON.stringify(data),
  });
  let body = {};
  try {
    body = await res.json();
  } catch (e) {
    body = {};
  }
  if (!res.ok) {
    const detail = body.detail;
    if (Array.isArray(detail)) {
      throw new Error(detail.map((d) => d.msg || String(d)).join("; "));
    }
    throw new Error(detail || res.statusText);
  }
  return body;
}

function showError(message) {
  const el = document.getElementById("error");
  if (el) {
    el.textContent = message;
    el.style.display = "block";
  }
}

function showInfo(message) {
  const el = document.getElementById("info");
  if (el) {
    el.textContent = message;
    el.style.display = "block";
  }
}
