/**
 * Single client-side source of the password policy, shared by all auth pages
 * and loadable in Node.js for tests. Returns an error message (German, for
 * display in the page) or null if the password satisfies the policy:
 * at least 8 chars, at most 1024 chars, 1 uppercase, 1 lowercase, 1 digit,
 * 1 special char.
 */

function passwordPolicyError(password) {
  if (password.length < 8) {
    return "Das Passwort muss mindestens 8 Zeichen lang sein.";
  }
  if (password.length > 1024) {
    return "Das Passwort darf h\u00f6chstens 1024 Zeichen lang sein.";
  }
  if (!/[A-Z]/.test(password)) {
    return "Das Passwort braucht mindestens einen Großbuchstaben.";
  }
  if (!/[a-z]/.test(password)) {
    return "Das Passwort braucht mindestens einen Kleinbuchstaben.";
  }
  if (!/[0-9]/.test(password)) {
    return "Das Passwort braucht mindestens eine Zahl.";
  }
  if (!/[-_!?=+.]/.test(password)) {
    return "Das Passwort braucht mindestens ein Sonderzeichen (-_!?=+.-).";
  }
  return null;
}

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { passwordPolicyError };
}
