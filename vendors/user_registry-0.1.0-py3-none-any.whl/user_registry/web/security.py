from __future__ import annotations

import secrets
from typing import Optional

from fastapi import Request
from itsdangerous import URLSafeTimedSerializer

from .config import AuthConfig


def make_serializer(config: AuthConfig) -> URLSafeTimedSerializer:
    return URLSafeTimedSerializer(config.secret_key)


def sign_session(config: AuthConfig, serializer: URLSafeTimedSerializer, email: str) -> str:
    epoch = config.registry.password_changed_at(email) or ""
    return serializer.dumps({"email": email, "pwd": epoch})


def read_session(
    request: Request, config: AuthConfig, serializer: URLSafeTimedSerializer
) -> Optional[str]:
    raw = request.cookies.get(config.session_cookie)
    if not raw:
        return None
    try:
        data = serializer.loads(raw, max_age=config.session_max_age)
    except Exception:
        return None
    email = data.get("email") if isinstance(data, dict) else None
    if not isinstance(email, str):
        return None
    epoch = config.registry.password_changed_at(email)
    if epoch is None or data.get("pwd") != epoch:
        return None
    return email


def new_csrf_token() -> str:
    return secrets.token_urlsafe(16)


def csrf_valid(request: Request, config: AuthConfig) -> bool:
    header = request.headers.get("x-csrf-token", "")
    cookie = request.cookies.get(config.csrf_cookie, "")
    return bool(header) and bool(cookie) and secrets.compare_digest(header, cookie)
