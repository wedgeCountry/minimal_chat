from __future__ import annotations

import importlib.resources as resources
import mimetypes
import os
from typing import Optional, Tuple

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse, Response

from .config import AuthConfig
from .security import make_serializer, new_csrf_token, read_session

_STATIC = resources.files("user_registry.web") / "static"


def _load_static(name: str) -> str:
    return (_STATIC / name).read_text(encoding="utf-8")


def _resolve_document(document: Optional[str], default_name: str) -> Tuple[str, str]:
    if document is None:
        return "html", _load_static(default_name)
    if document.startswith(("http://", "https://")):
        return "redirect", document
    if os.path.exists(document):
        with open(document, encoding="utf-8") as fh:
            return "html", fh.read()
    return "html", document


def _resolve_background(config: AuthConfig) -> str:
    image = config.background_image
    if image is None:
        return "none"
    if os.path.exists(image):
        return f'url("{config.prefix}/static/background-image")'
    return f'url("{image}")'


def create_pages_router(config: AuthConfig) -> APIRouter:
    router = APIRouter(tags=["auth-pages"])
    serializer = make_serializer(config)

    def _session_email(request: Request) -> Optional[str]:
        email = read_session(request, config, serializer)
        if email is None or not config.registry.user_exists(email):
            return None
        if config.require_reaccept:
            acceptance = config.registry.get_terms_acceptance(email)
            if acceptance is None or acceptance["terms_version"] != config.terms_version:
                return None
        return email

    def _render(html: str, token: Optional[str] = None) -> str:
        html = html.replace("__PREFIX__", config.prefix).replace(
            "__BACKGROUND_IMAGE__", _resolve_background(config)
        )
        html = html.replace(
            "__LOGIN_REDIRECT__",
            config.login_redirect or f"{config.prefix}/change-password",
        )
        if token is not None:
            html = html.replace("__CSRF_TOKEN__", token)
        return html

    def _page(name: str):
        def handler(request: Request) -> HTMLResponse:
            token = new_csrf_token()
            resp = HTMLResponse(_render(_load_static(name), token))
            resp.set_cookie(
                config.csrf_cookie,
                token,
                httponly=False,
                samesite="lax",
                secure=config.cookie_secure,
            )
            return resp

        return handler

    def _protected_page(name: str):
        def handler(request: Request) -> Response:
            if _session_email(request) is None:
                return RedirectResponse(f"{config.prefix}/login", status_code=303)
            return _page(name)(request)

        return handler

    def _register_page(request: Request) -> Response:
        if config.require_invitation:
            token = request.query_params.get("invite", "")
            if not config.registry.invitation_token_valid(token):
                return RedirectResponse(f"{config.prefix}/login", status_code=303)
        return _page("register.html")(request)

    router.add_api_route("/register", _register_page, methods=["GET"])
    router.add_api_route("/login", _page("login.html"), methods=["GET"])
    router.add_api_route("/forgot-password", _page("forgot_password.html"), methods=["GET"])
    router.add_api_route("/reset-password", _page("reset_password.html"), methods=["GET"])
    router.add_api_route(
        "/change-password", _protected_page("change_password.html"), methods=["GET"]
    )
    router.add_api_route("/delete", _protected_page("delete.html"), methods=["GET"])

    if config.background_image and os.path.exists(config.background_image):
        image_path = config.background_image

        @router.get("/static/background-image")
        def background_image() -> Response:
            media_type = mimetypes.guess_type(image_path)[0] or "application/octet-stream"
            with open(image_path, "rb") as fh:
                return Response(fh.read(), media_type=media_type)

    @router.get("/static/{name}")
    def static_file(name: str) -> Response:
        if "/" in name or ".." in name or not name.endswith((".js", ".css")):
            raise HTTPException(status_code=404, detail="not found")
        media_type = "application/javascript" if name.endswith(".js") else "text/css"
        return Response(_load_static(name), media_type=media_type)

    @router.get("/terms")
    def terms() -> Response:
        kind, value = _resolve_document(config.terms_document, "terms_de.html")
        if kind == "redirect":
            return RedirectResponse(value, status_code=307)
        return HTMLResponse(_render(value))

    @router.get("/impressum")
    def impressum() -> Response:
        kind, value = _resolve_document(config.imprint_document, "impressum.html")
        if kind == "redirect":
            return RedirectResponse(value, status_code=307)
        return HTMLResponse(_render(value))

    return router
