"""Canonical password policy for the user registry.

This module is the single server-side point where the password policy is
defined. ``password_policy_error`` returns an error message for a password
that violates the policy, or ``None`` if the password is acceptable. The
client-side mirror lives in ``web/static/password_validation.js`` and is
covered against the same cases by ``tests/test_password_policy.py`` and
``tests/test_password_policy_js.js``.
"""

from __future__ import annotations

import re
from typing import Optional

_MIN_LENGTH = 8
_MAX_LENGTH = 1024

_UPPERCASE_RE = re.compile(r"[A-Z]")
_LOWERCASE_RE = re.compile(r"[a-z]")
_DIGIT_RE = re.compile(r"[0-9]")
_SPECIAL_RE = re.compile(r"[-_!?=+.]")


def password_policy_error(password: str) -> Optional[str]:
    """Return an error message if ``password`` violates the policy, else ``None``.

    Policy: at least 8 characters, one uppercase letter, one lowercase
    letter, one digit and one special character from ``-_!?=+.-``, and at
    most 1024 characters (bounds the KDF input size).
    """
    if len(password) < _MIN_LENGTH:
        return "Password must be at least 8 characters long."
    if len(password) > _MAX_LENGTH:
        return "Password must be at most 1024 characters long."
    if not _UPPERCASE_RE.search(password):
        return "Password must contain at least one uppercase letter."
    if not _LOWERCASE_RE.search(password):
        return "Password must contain at least one lowercase letter."
    if not _DIGIT_RE.search(password):
        return "Password must contain at least one digit."
    if not _SPECIAL_RE.search(password):
        return "Password must contain at least one special character (-_!?=+.-)."
    return None
