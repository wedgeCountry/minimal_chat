import os
import tempfile

import numpy as np

from ..audio import decode_wav
from .base import BaseTTSEngine

MELO_LANG_CODES = {"en": "EN"}


class MeloTTSService(BaseTTSEngine):
    def __init__(self, device: str = "cpu", speaker: str | None = None):
        self._device = device
        self._speaker = speaker
        self._models: dict[str, object] = {}
        self._sample_rate: int | None = None

    @property
    def sample_rate(self) -> int:
        if self._sample_rate is None:
            self._model("en")
        assert self._sample_rate is not None
        return self._sample_rate

    def _model(self, language: str | None):
        lang = language or "en"
        code = MELO_LANG_CODES.get(lang)
        if code is None:
            raise ValueError(f"MeloTTS service does not support language '{lang}'")
        if code not in self._models:
            from melo.api import TTS

            model = TTS(language=code, device=self._device)
            self._models[code] = model
            self._sample_rate = int(model.hps.data.sampling_rate)
        return self._models[code]

    def _speaker_id(self, model, voice: str | None) -> int:
        spk2id = model.hps.data.spk2id
        key = voice or self._speaker
        if key is not None and key in spk2id:
            return spk2id[key]
        if key is not None and str(key).isdigit():
            return int(key)
        if "EN-Default" in spk2id:
            return spk2id["EN-Default"]
        return next(iter(spk2id.values()))

    def synthesize(self, text: str, voice: str | None = None, language: str | None = None) -> np.ndarray:
        model = self._model(language)
        speaker = self._speaker_id(model, voice)
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "out.wav")
            model.tts_to_file(text, speaker, path)
            with open(path, "rb") as f:
                x, sr = decode_wav(f.read())
        self._sample_rate = sr
        return np.ascontiguousarray(x, dtype=np.float32)
