import numpy as np

from .base import BaseTTSEngine

DEFAULT_VOICES = {"en": "en_US-lessac-high", "de": "de_DE-thorsten-high"}


def _voice_paths(repo: str, voice_id: str) -> tuple[str, str]:
    parts = voice_id.split("-")
    locale, speaker, quality = parts[0], parts[-2], parts[-1]
    lang = locale.split("_")[0]
    base = f"{lang}/{locale}/{speaker}/{quality}/{voice_id}"
    return f"{base}.onnx", f"{base}.onnx.json"


class PiperService(BaseTTSEngine):
    def __init__(self, repo: str = "rhasspy/piper-voices", voices: dict[str, str] | None = None):
        self._repo = repo
        self._voice_ids = {**DEFAULT_VOICES, **(voices or {})}
        self._voices: dict[str, object] = {}

    def _voice_id_for(self, language: str | None) -> str:
        lang = language or "en"
        voice_id = self._voice_ids.get(lang)
        if voice_id is None:
            raise ValueError(f"Piper service has no voice configured for language '{lang}'")
        return voice_id

    def _voice_by_id(self, voice_id: str):
        if voice_id not in self._voices:
            from huggingface_hub import hf_hub_download
            from piper import PiperVoice

            model_path, config_path = _voice_paths(self._repo, voice_id)
            model = hf_hub_download(self._repo, model_path)
            config = hf_hub_download(self._repo, config_path)
            self._voices[voice_id] = PiperVoice.load(model, config)
        return self._voices[voice_id]

    def _voice(self, language: str | None):
        return self._voice_by_id(self._voice_id_for(language))

    @property
    def sample_rate(self) -> int:
        return int(self._voice("en").config.sample_rate)

    def sample_rate_for(self, language: str | None = None) -> int:
        return int(self._voice(language).config.sample_rate)

    def synthesize(self, text: str, voice: str | None = None, language: str | None = None) -> np.ndarray:
        voice_id = voice if voice in self._voice_ids.values() else self._voice_id_for(language)
        v = self._voice_by_id(voice_id)
        chunks = [np.frombuffer(c.audio_int16_bytes, dtype=np.int16) for c in v.synthesize(text)]
        if not chunks:
            return np.zeros(0, dtype=np.float32)
        return (np.concatenate(chunks).astype(np.float32) / 32768.0)
