import re
from typing import Iterator, Protocol

import numpy as np

ABBREVIATIONS = {
    "mr.", "mrs.", "ms.", "dr.", "prof.", "st.", "jr.", "sr.",
    "vs.", "etc.", "e.g.", "i.e.", "no.", "fig.",
}

_BOUNDARY_RE = re.compile(r"([.!?]+)([\"')\]]*)(\s+)")
_TERMINAL_RE = re.compile(r"([.!?]+)([\"')\]]*)\s*$")
_WORD_RE = re.compile(r"\S+$")
_NEXT_WORD_RE = re.compile(r"[\"'(\[]*(\S)")


def _is_sentence_end(text: str, term_start: int, term: str) -> bool:
    before = text[:term_start]
    word = _WORD_RE.search(before)
    return not (word and (word.group(0) + term).lower() in ABBREVIATIONS)


def _next_word_is_capitalized(text: str, pos: int) -> bool:
    m = _NEXT_WORD_RE.match(text, pos)
    return bool(m) and m.group(1).isupper()


def take_complete_sentences(text: str) -> tuple[list[str], str]:
    parts: list[str] = []
    prev = 0
    for m in _BOUNDARY_RE.finditer(text):
        if not _is_sentence_end(text, m.start(1), m.group(1)):
            continue
        if not _next_word_is_capitalized(text, m.end()):
            continue
        piece = text[prev : m.start(3)].strip()
        if piece:
            parts.append(piece)
        prev = m.end()
    tail = text[prev:]
    end = _TERMINAL_RE.search(tail)
    if end and _is_sentence_end(tail, end.start(1), end.group(1)):
        piece = tail[: end.end()].strip()
        if piece:
            parts.append(piece)
        return parts, ""
    return parts, tail


class TTSEngine(Protocol):
    sample_rate: int

    def synthesize(self, text: str, voice: str | None = None, language: str | None = None) -> np.ndarray: ...

    def synthesize_stream(
        self, sentences: Iterator[str], voice: str | None = None, language: str | None = None
    ) -> Iterator[np.ndarray]: ...

    def sample_rate_for(self, language: str | None = None) -> int: ...


class BaseTTSEngine:
    sample_rate: int

    def synthesize(self, text: str, voice: str | None = None, language: str | None = None) -> np.ndarray:
        raise NotImplementedError

    def synthesize_stream(
        self, sentences: Iterator[str], voice: str | None = None, language: str | None = None
    ) -> Iterator[np.ndarray]:
        for s in sentences:
            if s.strip():
                yield self.synthesize(s, voice, language)

    def sample_rate_for(self, language: str | None = None) -> int:
        return self.sample_rate
