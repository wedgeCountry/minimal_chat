from .base import TTSEngine, take_complete_sentences

__all__ = ["TTSEngine", "take_complete_sentences", "create_tts_engine", "TTS_ENGINES"]


def _build_melotts(settings):
    from .melotts import MeloTTSService

    device = settings.tts_device
    if device == "auto":
        import torch

        device = "cuda" if torch.cuda.is_available() else "cpu"
    return MeloTTSService(device=device, speaker=settings.melotts_speaker)


def _build_piper(settings):
    from .piper import PiperService

    return PiperService(
        repo=settings.piper_repo,
        voices={"en": settings.piper_voice_en, "de": settings.piper_voice_de},
    )


TTS_ENGINES = {
    "melotts": _build_melotts,
    "piper": _build_piper,
}


class DispatchTTS:
    def __init__(self, settings):
        self._settings = settings
        self._services: dict[tuple[str, str], TTSEngine] = {}

    def _engine_name(self, language: str | None) -> str:
        lang = language or "en"
        override = {"en": self._settings.tts_engine_en, "de": self._settings.tts_engine_de}.get(lang)
        return override or self._settings.tts_engine

    def _service(self, language: str | None) -> TTSEngine:
        lang = language or "en"
        name = self._engine_name(lang)
        key = (name, lang)
        if key not in self._services:
            builder = TTS_ENGINES.get(name)
            if builder is None:
                raise ValueError(
                    f"unknown TTS engine '{name}' for language '{lang}' "
                    f"(available: {sorted(TTS_ENGINES)}; configure via TTS_ENGINE / TTS_ENGINE_EN / TTS_ENGINE_DE)"
                )
            self._services[key] = builder(self._settings)
        return self._services[key]

    @property
    def sample_rate(self) -> int:
        return self.sample_rate_for(None)

    def sample_rate_for(self, language: str | None = None) -> int:
        return self._service(language).sample_rate

    def synthesize(self, text: str, voice: str | None = None, language: str | None = None):
        return self._service(language).synthesize(text, voice, language)

    def synthesize_stream(self, sentences, voice: str | None = None, language: str | None = None):
        yield from self._service(language).synthesize_stream(sentences, voice, language)


def create_tts_engine(settings):
    return DispatchTTS(settings)
