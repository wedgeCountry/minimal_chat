import json
from typing import Protocol

import numpy as np

SUPPORTED_LANGUAGES = ("en", "de")

LID_REPO = "deepghs/silero-lang95-onnx"


class LanguageDetector(Protocol):
    def detect(self, audio: np.ndarray) -> tuple[str, float]: ...


class SileroLangDetector:
    def __init__(self, sample_rate: int = 16000, allowed: tuple[str, ...] = SUPPORTED_LANGUAGES, top_n: int = 10):
        import onnxruntime as ort
        from huggingface_hub import hf_hub_download

        self.sample_rate = sample_rate
        self.allowed = tuple(allowed)
        self._top_n = top_n
        self._session = ort.InferenceSession(
            hf_hub_download(LID_REPO, "lang_classifier_95.onnx"),
            providers=["CPUExecutionProvider"],
        )
        self._input_name = self._session.get_inputs()[0].name
        with open(hf_hub_download(LID_REPO, "lang_dict_95.json"), encoding="utf-8") as f:
            self._lang_dict = json.load(f)

    def detect(self, audio: np.ndarray) -> tuple[str, float]:
        x = np.asarray(audio, dtype=np.float32)[None, :]
        logits = self._session.run(None, {self._input_name: x})[0][0]
        probs = np.exp(logits) / np.exp(logits).sum()
        order = np.argsort(probs)[::-1]
        for i in order[: self._top_n]:
            code = self._lang_dict[str(int(i))].split(",")[0].strip()
            if code in self.allowed:
                return code, float(probs[i])
        i = int(order[0])
        code = self._lang_dict[str(i)].split(",")[0].strip()
        return code, float(probs[i])
