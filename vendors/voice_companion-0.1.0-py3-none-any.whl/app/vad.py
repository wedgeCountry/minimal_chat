from collections import deque

import numpy as np


def frame_size(sample_rate: int) -> int:
    return 512 if sample_rate == 16000 else int(round(sample_rate * 0.032))


class FrameVAD:
    def __call__(self, frame: np.ndarray) -> bool:
        raise NotImplementedError

    def reset(self) -> None:
        pass


class SileroVAD(FrameVAD):
    def __init__(self, threshold: float = 0.5, sample_rate: int = 16000):
        import torch
        from silero_vad import load_silero_vad

        self._torch = torch
        self._model = load_silero_vad(onnx=True)
        self._threshold = threshold
        self._sr = sample_rate
        self._window = frame_size(sample_rate)
        self._leftover = np.zeros(0, dtype=np.float32)

    @property
    def window(self) -> int:
        return self._window

    def reset(self) -> None:
        self._leftover = np.zeros(0, dtype=np.float32)

    def __call__(self, frame: np.ndarray) -> bool:
        buf = np.concatenate([self._leftover, frame.astype(np.float32)])
        if buf.size < self._window:
            self._leftover = buf
            return False
        chunk = buf[: self._window]
        self._leftover = buf[self._window :]
        prob = float(self._model(self._torch.from_numpy(chunk), self._sr))
        return prob >= self._threshold


class Endpointing:
    def __init__(
        self,
        vad: FrameVAD,
        sample_rate: int = 16000,
        min_speech_ms: int = 250,
        silence_ms: int = 800,
        speech_pad_ms: int = 300,
    ):
        self.vad = vad
        self.sr = sample_rate
        self.frame = frame_size(sample_rate)
        self.min_speech = int(round(sample_rate * min_speech_ms / 1000))
        self.silence = int(round(sample_rate * silence_ms / 1000))
        self.pad = int(round(sample_rate * speech_pad_ms / 1000))
        self._pre: deque = deque(maxlen=max(1, self.pad // self.frame))
        self._seg: list[np.ndarray] = []
        self._rem = np.zeros(0, dtype=np.float32)
        self._in_speech = False
        self._speech_run = 0
        self._silence_run = 0

    @property
    def current_segment_samples(self) -> int:
        return sum(int(s.size) for s in self._seg)

    def current_segment_audio(self) -> np.ndarray | None:
        if not self._seg:
            return None
        return np.concatenate(self._seg)

    def push(self, samples: np.ndarray) -> list[np.ndarray]:
        finalized: list[np.ndarray] = []
        buf = np.concatenate([self._rem, samples.astype(np.float32)])
        n_frames = buf.size // self.frame
        for i in range(n_frames):
            frame = buf[i * self.frame : (i + 1) * self.frame]
            if self.vad(frame):
                if not self._in_speech:
                    self._start_segment()
                self._speech_run += frame.size
                self._silence_run = 0
                self._seg.append(frame)
            elif self._in_speech:
                self._silence_run += frame.size
                self._seg.append(frame)
                if self._silence_run >= self.silence:
                    finalized.extend(self._close_segment())
            else:
                self._pre.append(frame)
        self._rem = buf[n_frames * self.frame :]
        return finalized

    def flush(self) -> list[np.ndarray]:
        return self._close_segment()

    def _start_segment(self) -> None:
        self._in_speech = True
        self._speech_run = 0
        self._silence_run = 0
        pre = np.concatenate(list(self._pre)) if self._pre else np.zeros(0, dtype=np.float32)
        self._seg = [pre]
        self._pre.clear()

    def _close_segment(self) -> list[np.ndarray]:
        out: list[np.ndarray] = []
        if self._in_speech and self._speech_run >= self.min_speech and self._seg:
            seg = np.concatenate(self._seg)
            trailing = int(self._silence_run)
            if trailing >= self.frame:
                seg = seg[: max(0, seg.size - min(trailing, seg.size))]
            out.append(seg)
        self._in_speech = False
        self._speech_run = 0
        self._silence_run = 0
        self._seg = []
        self._rem = np.zeros(0, dtype=np.float32)
        self.vad.reset()
        return out
