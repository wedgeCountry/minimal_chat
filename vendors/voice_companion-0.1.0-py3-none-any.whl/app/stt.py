from typing import Protocol

import numpy as np

from .audio import pcm16_to_float32
from .lid import SUPPORTED_LANGUAGES
from .vad import Endpointing


class STTEngine(Protocol):
    sample_rate: int

    def transcribe(self, audio: np.ndarray, language: str | None = None, vad: bool = True) -> str: ...

    def detect_language(self, audio: np.ndarray) -> tuple[str, float]: ...


class FasterWhisperSTT:
    sample_rate = 16000

    def __init__(
        self,
        model_size: str = "small",
        device: str = "auto",
        compute_type: str = "int8_float16",
        vad_filter_min_silence_ms: int = 800,
        speech_pad_ms: int = 300,
        min_speech_duration_ms: int = 250,
    ):
        from faster_whisper import WhisperModel

        self._model = WhisperModel(model_size, device=device, compute_type=compute_type)
        self._vad_params = dict(
            min_silence_duration_ms=vad_filter_min_silence_ms,
            speech_pad_ms=speech_pad_ms,
            min_speech_duration_ms=min_speech_duration_ms,
        )

    def transcribe(self, audio: np.ndarray, language: str | None = None, vad: bool = True) -> str:
        kwargs = dict(beam_size=5, vad_filter=vad)
        if vad:
            kwargs["vad_parameters"] = self._vad_params
        segments, _ = self._model.transcribe(audio, language=language, **kwargs)
        return " ".join(s.text.strip() for s in segments if s.text.strip()).strip()

    def detect_language(self, audio: np.ndarray) -> tuple[str, float]:
        language, probability, all_probs = self._model.detect_language(audio)
        allowed = [p for p in all_probs if p[0] in SUPPORTED_LANGUAGES]
        if allowed:
            return max(allowed, key=lambda p: p[1])
        return language or SUPPORTED_LANGUAGES[0], probability


class STTStreamSession:
    def __init__(
        self,
        engine: STTEngine,
        endpointing: Endpointing,
        language: str | None = None,
        partial_every_ms: int = 2000,
        detector=None,
    ):
        self.engine = engine
        self.endpointing = endpointing
        self.language = language
        self.language_probability: float | None = None
        self.detector = detector
        self.partial_every = int(round(endpointing.sr * partial_every_ms / 1000))
        self._since_partial = 0
        self._just_detected = False

    def _resolve_language(self, seg: np.ndarray) -> str:
        if self.language is None:
            if self.detector is not None:
                self.language, self.language_probability = self.detector.detect(seg)
            else:
                self.language, self.language_probability = self.engine.detect_language(seg)
            self._just_detected = True
        return self.language

    def _event(self, kind: str, text: str, language: str) -> dict:
        event = {"type": kind, "text": text, "language": language}
        if self._just_detected:
            event["language_probability"] = self.language_probability
            self._just_detected = False
        return event

    def _process_segments(self, segments, kind: str = "final") -> list[dict]:
        events: list[dict] = []
        for seg in segments:
            language = self._resolve_language(seg)
            text = self.engine.transcribe(seg, language=language, vad=True)
            if text:
                events.append(self._event(kind, text, language))
        return events

    def feed(self, pcm: bytes) -> list[dict]:
        events: list[dict] = []
        x = pcm16_to_float32(pcm)
        events.extend(self._process_segments(self.endpointing.push(x)))
        self._since_partial += x.size
        if self.endpointing.current_segment_samples >= self.partial_every and self._since_partial >= self.partial_every:
            self._since_partial = 0
            seg = self.endpointing.current_segment_audio()
            if seg is not None and seg.size > 0:
                language = self._resolve_language(seg)
                text = self.engine.transcribe(seg, language=language, vad=True)
                if text:
                    events.append(self._event("partial", text, language))
        return events

    def finish(self) -> list[dict]:
        events = self._process_segments(self.endpointing.flush())
        events.append({"type": "done"})
        return events
