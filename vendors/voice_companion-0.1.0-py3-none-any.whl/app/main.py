import json
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import FastAPI, File, HTTPException, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import Response
from pydantic import BaseModel

from .audio import decode_wav, float32_to_pcm16, resample_linear, wav_bytes
from .config import Settings, get_settings
from .lid import SileroLangDetector
from .stt import FasterWhisperSTT, STTStreamSession
from .tts import create_tts_engine, take_complete_sentences
from .vad import Endpointing, SileroVAD

Language = Literal["en", "de"]
AutoLanguage = Literal["en", "de", "auto"]


def _resolve_stt_language(param: AutoLanguage | None, default: str | None) -> str | None:
    if param in ("en", "de"):
        return param
    if param is None:
        return default
    return None


class TTSRequest(BaseModel):
    text: str
    voice: str | None = None
    language: Language | None = None


def create_app(
    settings: Settings | None = None,
    stt_engine=None,
    tts_engine=None,
    vad_factory=None,
    lid_factory=None,
) -> FastAPI:
    settings = settings or get_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if app.state.stt is None:
            app.state.stt = FasterWhisperSTT(
                model_size=settings.stt_model,
                device=settings.stt_device,
                compute_type=settings.stt_compute_type,
                vad_filter_min_silence_ms=settings.vad_filter_min_silence_ms,
                speech_pad_ms=settings.speech_pad_ms,
                min_speech_duration_ms=settings.min_speech_ms,
            )
        if app.state.tts is None:
            app.state.tts = create_tts_engine(settings)
        yield

    app = FastAPI(title="voice-companion", lifespan=lifespan)
    app.state.settings = settings
    app.state.stt = stt_engine
    app.state.tts = tts_engine
    app.state.vad_factory = vad_factory or (
        lambda: SileroVAD(threshold=settings.vad_threshold, sample_rate=settings.sample_rate)
    )
    app.state.lid_factory = lid_factory or (lambda: SileroLangDetector(sample_rate=settings.sample_rate))

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.post("/v1/stt")
    async def stt(file: UploadFile = File(...), language: AutoLanguage | None = None):
        data = await file.read()
        x, sr = decode_wav(data)
        x = resample_linear(x, sr, settings.sample_rate)
        lang = _resolve_stt_language(language, settings.stt_language)
        if lang is None:
            lang, probability = app.state.stt.detect_language(x)
            text = app.state.stt.transcribe(x, language=lang, vad=True)
            return {"text": text, "language": lang, "language_probability": probability}
        text = app.state.stt.transcribe(x, language=lang, vad=True)
        return {"text": text, "language": lang}

    @app.websocket("/v1/stt/stream")
    async def stt_stream(ws: WebSocket, language: AutoLanguage | None = None):
        await ws.accept()
        endpointing = Endpointing(
            app.state.vad_factory(),
            sample_rate=settings.sample_rate,
            min_speech_ms=settings.min_speech_ms,
            silence_ms=settings.silence_ms,
            speech_pad_ms=settings.speech_pad_ms,
        )
        session = STTStreamSession(
            app.state.stt,
            endpointing,
            language=_resolve_stt_language(language, settings.stt_language),
            partial_every_ms=settings.partial_every_ms,
            detector=app.state.lid_factory(),
        )
        try:
            while True:
                msg = await ws.receive()
                if msg.get("bytes") is not None:
                    for event in session.feed(msg["bytes"]):
                        await ws.send_json(event)
                elif msg.get("text") is not None:
                    ctrl = json.loads(msg["text"])
                    if ctrl.get("type") == "end":
                        for event in session.finish():
                            await ws.send_json(event)
                        break
        except WebSocketDisconnect:
            pass

    @app.post("/v1/tts")
    async def tts(req: TTSRequest):
        try:
            audio = app.state.tts.synthesize(req.text, req.voice or settings.tts_voice, language=req.language)
            sample_rate = app.state.tts.sample_rate_for(req.language)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        pcm = float32_to_pcm16(audio)
        return Response(content=wav_bytes(pcm, sample_rate), media_type="audio/wav")

    async def _synthesize_and_send(ws: WebSocket, sentences, voice: str, language: Language | None) -> bool:
        try:
            for chunk in app.state.tts.synthesize_stream(iter(sentences), voice, language=language):
                await ws.send_bytes(float32_to_pcm16(chunk))
            return True
        except ValueError as e:
            await ws.send_json({"type": "error", "message": str(e)})
            return False

    @app.websocket("/v1/tts/stream")
    async def tts_stream(ws: WebSocket, language: Language | None = None):
        await ws.accept()
        await ws.send_json(
            {"type": "start", "sample_rate": app.state.tts.sample_rate_for(language), "format": "pcm16", "channels": 1}
        )
        buf = ""
        try:
            while True:
                msg = await ws.receive()
                if msg.get("text") is None:
                    continue
                ctrl = json.loads(msg["text"])
                if ctrl.get("type") == "text":
                    buf += ctrl.get("text", "")
                    complete, buf = take_complete_sentences(buf)
                    if not await _synthesize_and_send(ws, complete, ctrl.get("voice") or settings.tts_voice, language):
                        break
                elif ctrl.get("type") == "end":
                    if buf.strip():
                        if not await _synthesize_and_send(ws, [buf], ctrl.get("voice") or settings.tts_voice, language):
                            break
                    await ws.send_json({"type": "done"})
                    break
        except WebSocketDisconnect:
            pass

    return app


app = create_app()
