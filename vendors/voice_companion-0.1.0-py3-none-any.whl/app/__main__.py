from app import DEFAULT_HOST, DEFAULT_PORT

if __name__ == "__main__":
    #sudo ufw allow 6563
    import uvicorn
    uvicorn.run("app.main:app",
                host=DEFAULT_HOST, port=DEFAULT_PORT,
                #ssl_certfile="./wedgecountry.de_ssl_certificate.cer",
                #ssl_keyfile="./_.wedgecountry.de_private_key.key"
                )
