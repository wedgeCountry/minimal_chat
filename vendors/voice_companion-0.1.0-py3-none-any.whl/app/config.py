import os
from dataclasses import dataclass
from pathlib import Path

ENV_FILE = Path(__file__).resolve().parent.parent / ".env"


def load_dotenv(path: Path = ENV_FILE) -> None:
    """Load KEY=VALUE pairs from a .env file into os.environ.

    Blank lines and '#' comments are ignored, values may be quoted.
    Variables already present in the environment take precedence.
    """
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        if key and key not in os.environ:
            os.environ[key] = value


load_dotenv()


def _env_int(key: str, default: str) -> int:
    return int(os.getenv(key, default))


def _env_float(key: str, default: str) -> float:
    return float(os.getenv(key, default))


def _env_str(key: str, default: str) -> str:
    return os.getenv(key, default)


def _env_opt(key: str) -> str | None:
    return os.getenv(key, "") or None


@dataclass
class Settings:
    sample_rate: int = 16000
    stt_model: str = "small"
    stt_device: str = "auto"
    stt_compute_type: str = "int8_float16"
    stt_language: str | None = None
    tts_engine: str = "piper"
    tts_engine_en: str | None = None
    tts_engine_de: str | None = "piper"
    tts_device: str = "auto"
    tts_voice: str | None = None
    melotts_speaker: str | None = None
    piper_repo: str = "rhasspy/piper-voices"
    piper_voice_en: str = "en_US-lessac-high"
    piper_voice_de: str = "de_DE-thorsten-high"
    vad_threshold: float = 0.5
    min_speech_ms: int = 250
    silence_ms: int = 800
    speech_pad_ms: int = 300
    vad_filter_min_silence_ms: int = 800
    partial_every_ms: int = 2000
    host: str = "127.0.0.1"
    port: int = 8000

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            sample_rate=_env_int("SAMPLE_RATE", "16000"),
            stt_model=_env_str("STT_MODEL", "small"),
            stt_device=_env_str("STT_DEVICE", "auto"),
            stt_compute_type=_env_str("STT_COMPUTE_TYPE", "int8_float16"),
            stt_language=_env_opt("STT_LANGUAGE"),
            tts_engine=_env_str("TTS_ENGINE", "piper"),
            tts_engine_en=_env_opt("TTS_ENGINE_EN"),
            tts_engine_de=_env_str("TTS_ENGINE_DE", "piper") or None,
            tts_device=_env_str("TTS_DEVICE", "auto"),
            tts_voice=_env_opt("TTS_VOICE"),
            melotts_speaker=_env_opt("MELOTTS_SPEAKER"),
            piper_repo=_env_str("PIPER_REPO", "rhasspy/piper-voices"),
            piper_voice_en=_env_str("PIPER_VOICE_EN", "en_US-lessac-high"),
            piper_voice_de=_env_str("PIPER_VOICE_DE", "de_DE-thorsten-high"),
            vad_threshold=_env_float("VAD_THRESHOLD", "0.5"),
            min_speech_ms=_env_int("MIN_SPEECH_MS", "250"),
            silence_ms=_env_int("SILENCE_MS", "800"),
            speech_pad_ms=_env_int("SPEECH_PAD_MS", "300"),
            vad_filter_min_silence_ms=_env_int("VAD_FILTER_MIN_SILENCE_MS", "800"),
            partial_every_ms=_env_int("PARTIAL_EVERY_MS", "2000"),
            host=_env_str("HOST", "127.0.0.1"),
            port=_env_int("PORT", "8000"),
        )


def get_settings() -> Settings:
    return Settings.from_env()
