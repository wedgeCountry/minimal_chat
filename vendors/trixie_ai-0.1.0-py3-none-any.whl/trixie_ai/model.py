from dataclasses import dataclass
from typing import Callable, Any


@dataclass
class LlmDefinition:
    api_base: str
    model: str
    api_key: str = ""

@dataclass
class LlmResponse:
    content: str
    reasoning_content: str
    finish_reason: str
    tool_calls: list[dict[str, Any]]

    def __str__(self):
        return self.content

@dataclass
class LlmToolParameter:
    name: str
    description: str
    type: str

class LlmTool:

    def __init__(self, callable: Callable[..., Any],
                 name: str, description: str, parameters: list[LlmToolParameter] = None, required_parameters: list[str] = None):
        self.callable = callable
        self.name = name
        self.description = description
        self.parameters = parameters or []
        self.required_parameters = required_parameters or []
        self.is_long_running_task = False

    def to_dict(self):
        if not self.parameters:
            return {
                "type": "function",
                "function": {
                    "name": self.name,
                    "description": self.description,
                }
            }

        params = {}
        for p in self.parameters:
            param = {
                "type": p.type,
                "description": p.description,
            }

            params[p.name] = param
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": params,
                    "required": self.required_parameters
                }
            }
        }


