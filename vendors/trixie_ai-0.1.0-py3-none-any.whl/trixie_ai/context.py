import json
import locale
import logging
import os.path
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from cryptography.fernet import Fernet


@dataclass
class LlmContext:

    system_prompt: list[str] = field(default_factory=list)
    messages: list[dict[str, str]] = field(default_factory=list)
    files: list[str] = field(default_factory=list)
    include_time: bool = False

    def add_message(self, role: str, content: str) -> None:
        self.messages.append({"role": role, "content": content})

    def add_system_prompt(self, prompt) -> None:
        self.system_prompt += [prompt]

    def add_file(self, file_path: str) -> None:
        if not os.path.isfile(file_path):
            raise FileNotFoundError(f"File '{file_path}' not found")
        if file_path not in self.files:
            self.files.append(file_path)

    def remove_file(self, file_path: str) -> None:
        if file_path in self.files:
            self.files.remove(file_path)

    def to_json(self) -> str:
        return json.dumps({
            "system_prompt": self.system_prompt,
            "history": self.messages,
            "files": self.files,
            "include_time": self.include_time
        }, indent=2)

    @classmethod
    def from_json(cls, data: str) -> "LlmContext":
        parsed = json.loads(data)
        return cls(
            system_prompt=parsed.get("system_prompt", []),
            messages=parsed.get("history", []),
            files=parsed.get("files", []),
            include_time = parsed.get("include_time", False),
        )

    def compile(self, reasoning:bool = False) -> list[dict[str, str]]:

        full_context = []

        full_context += [{"role": "system", "content": sp} for sp in self.system_prompt]

        if self.include_time:
            full_context.append({"role": "system", "content": f"The current time is {datetime.now()}"})

        if reasoning:
            full_context.append({
            "role": "system",
            "content": "<|think|>"
        })

        for file in self.files:
            with open(file) as f:
                file_content = f.readlines()

            full_context.append({
                "role": "system",
                "content": """Content of the '%s': ´´´file
                %s
                ´´´
                """ % (file, file_content)
            })

        full_context += self.messages

        return full_context




log = logging.getLogger(__name__)

_CONTEXTS_DIR = Path("contexts")
_KEY_FILE     = _CONTEXTS_DIR / ".key"

def _load_or_create_key() -> Fernet:
    _CONTEXTS_DIR.mkdir(exist_ok=True)
    if _KEY_FILE.exists():
        return Fernet(_KEY_FILE.read_bytes())
    key = Fernet.generate_key()
    _KEY_FILE.write_bytes(key)
    _KEY_FILE.chmod(0o600)
    log.info(f"Generated new encryption key at {_KEY_FILE}")
    return Fernet(key)

_fernet = None

def _get_fernet() -> Fernet:
    global _fernet
    if _fernet is None:
        _fernet = _load_or_create_key()
    return _fernet

def _context_path(user_id: str) -> Path:
    safe_name = user_id.lstrip("+")
    return _CONTEXTS_DIR / f"{safe_name}.ctx"

def load_context(user_id: str) -> LlmContext:
    path = _context_path(user_id)
    if not path.exists():
        return LlmContext()
    try:
        decrypted = _get_fernet().decrypt(path.read_bytes())
        return LlmContext.from_json(decrypted)
    except Exception as e:
        log.warning(f"Could not load context for {user_id}: {e}")
        return LlmContext()


def save_context(user_id: str, context: LlmContext) -> None:
    path = _context_path(user_id)
    try:
        encrypted = _get_fernet().encrypt(context.to_json().encode())
        path.write_bytes(encrypted)
        path.chmod(0o600)
    except Exception as e:
        log.warning(f"Could not save context for {user_id}: {e}")

def delete_context(user_id: str) -> None:
    path = _context_path(user_id)
    if path.exists():
        path.unlink()
        log.info(f"Deleted context for {user_id}")

# sudo locale-gen de_DE.UTF-8
# sudo update-locale
try:
    locale.setlocale(locale.LC_TIME, 'de_DE.UTF-8')
except locale.Error:
    log.warning("de_DE.UTF-8 locale not available, keeping default locale")

class ContextLoader:

    def load_context(self, user_id) -> LlmContext:
        return load_context(user_id) or LlmContext()

    def save(self, user_id:str, context:LlmContext):
        save_context(user_id, context)
