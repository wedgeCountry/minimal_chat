from trixie_ai.backend import call_llm
from trixie_ai.config import get_default_config
from trixie_ai.context import LlmContext
from trixie_ai.model import LlmDefinition


SUMMARIZE_SEARCH_SYSTEM_PROMPT = """
You are a summary assistant. 
Your task is to summarize a given text with respect to a given question.  
You create a concise summary. 
You never invent content.  
You never add information outside the given text! 
You never add any explanations or comments of your own. 
You return only the summary. 
You stay with the facts always!
You add all relevant facts and ideas to the summary. 
The formatting of the summary is simple, structured only with headings and text.  
"""
SUMMARIZE_SEARCH_PROMPT = "Summarize the given text with respect to the given question. Return the summary only."

def summarize_text_content(search_query: str, text_content: str, llm: LlmDefinition = None):
    llm = llm or get_default_config().lm_studio
    context = LlmContext()
    context.add_system_prompt(SUMMARIZE_SEARCH_SYSTEM_PROMPT)

    context.add_message("user", """```given text\n%s\n```""" % text_content)
    context.add_message("user", """```given question\n%s\n```""" % search_query)

    result = call_llm(llm, SUMMARIZE_SEARCH_PROMPT, context, reasoning=False)
    return result.content

