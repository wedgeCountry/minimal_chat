import ast
import builtins
import json
import sys
from typing import Any

try:
    import resource  # POSIX only
except ImportError:  # pragma: no cover - Windows has no resource module
    resource = None  # type: ignore[assignment]

class UnsafeCodeError(Exception):
    """Raised when the provided source fails static safety validation."""

class ExtractionError(Exception):
    """Raised when execution fails, times out, or the result is invalid."""

REQUIRED_FUNCTION_NAME = "extract_content"
DEFAULT_TIMEOUT_SECONDS = 5.0
DEFAULT_MEMORY_LIMIT_BYTES = 1024 * 1024 * 1024  # 1 GB

SAFE_BUILTIN_NAMES = ("len", "range", "enumerate", "zip", "map", "filter", "sorted",
    "reversed", "min", "max", "sum", "abs", "round", "any", "all",
    "isinstance", "issubclass", "str", "int", "float", "bool", "list",
    "dict", "set", "tuple", "frozenset", "repr", "__import__", "hasattr",)
SAFE_BUILTINS: dict[str, Any] = {name: getattr(builtins, name) for name in SAFE_BUILTIN_NAMES}
SAFE_BUILTINS.update({"True": True, "False": False, "None": None})

FORBIDDEN_NAMES = frozenset({
    "eval", "exec", "compile", "open", "input", "exit",
    "quit", "globals", "locals", "vars", "getattr", "setattr", "delattr",
    "breakpoint", "help", "memoryview",
})
FORBIDDEN_ATTRIBUTES = frozenset({"format", "format_map"})
ALLOWED_IMPORT_MODULES = frozenset({
    "re", "html", "html.parser", "json", "string", "urllib.parse", "bs4"
})

def validate_source(source: str) -> None:
    try:
        tree = ast.parse(source, mode="exec")
    except SyntaxError as error:
        raise UnsafeCodeError(f"code does not parse: {error}") from error

    function_names = {node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}
    if REQUIRED_FUNCTION_NAME not in function_names:
        raise UnsafeCodeError(f"code must define a function named '{REQUIRED_FUNCTION_NAME}'")

    for node in ast.walk(tree):
        _validate_node(node)

def _validate_node(node: ast.AST) -> None:
    if isinstance(node, (ast.Import, ast.ImportFrom)):
        _validate_import(node)
    elif isinstance(node, ast.Attribute):
        if node.attr.startswith("__") or node.attr in FORBIDDEN_ATTRIBUTES:
            raise UnsafeCodeError(f"access to attribute '{node.attr}' is not allowed")
    elif isinstance(node, ast.Name) and node.id in FORBIDDEN_NAMES:
        raise UnsafeCodeError(f"use of '{node.id}' is not allowed")
    elif isinstance(node, (ast.Global, ast.Nonlocal)):
        raise UnsafeCodeError("global/nonlocal statements are not allowed")
    elif isinstance(node, ast.Constant) and isinstance(node.value, str) and "__" in node.value:
        raise UnsafeCodeError("string literals containing '__' are not allowed")

def _validate_import(node: ast.Import | ast.ImportFrom) -> None:
    module_names = (
        [alias.name for alias in node.names]
        if isinstance(node, ast.Import)
        else [node.module or ""]
    )
    for module_name in module_names:
        if module_name not in ALLOWED_IMPORT_MODULES:
            raise UnsafeCodeError(f"import of '{module_name}' is not allowed")

def _apply_resource_limits(memory_limit_bytes: int, timeout_seconds: float) -> None:
    if resource is None:
        return  # best-effort only; not available on Windows
    try:
        resource.setrlimit(resource.RLIMIT_AS, (memory_limit_bytes, memory_limit_bytes))
        cpu_seconds = max(1, int(timeout_seconds))
        resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds))
    except (ValueError, OSError):
        pass  # some environments (containers, certain OSes) disallow this


def main() -> None:
    request = json.loads(sys.stdin.read())

    try:
        _apply_resource_limits(request["memory_limit_bytes"], request["timeout_seconds"])
        validate_source(request["source"])

        sandbox_globals = {"__builtins__": SAFE_BUILTINS}
        exec(compile(request["source"], "<extract_content>", "exec"), sandbox_globals)

        extract_content = sandbox_globals.get(REQUIRED_FUNCTION_NAME)
        if not callable(extract_content):
            raise ExtractionError(f"'{REQUIRED_FUNCTION_NAME}' was not defined as a callable")

        result = extract_content(request["html"])
        response = {"status": "ok", "payload": json.dumps(result)}
    except UnsafeCodeError as error:
        response = {"status": "unsafe", "payload": str(error)}
    except TypeError as error:
        response = {"status": "error", "payload": f"result is not JSON-serializable: {error}"}
    except Exception as error:
        response = {"status": "error", "payload": f"{type(error).__name__}: {error}"}

    sys.stdout.write(json.dumps(response))


if __name__ == "__main__":
    main()