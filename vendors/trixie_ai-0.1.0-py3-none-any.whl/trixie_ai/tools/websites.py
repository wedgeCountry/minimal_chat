import logging
from dataclasses import dataclass

from trixie_ai.model import LlmDefinition, LlmTool, LlmToolParameter
from trixie_ai.tools.websites_html import visit_url_internal

logger = logging.getLogger(__name__)

@dataclass
class WebsiteContent:
    url: str
    content: str = ""


def visit_urls(urls: list[str], llm: LlmDefinition = None) -> list[WebsiteContent]:
    results = []
    for url in urls:
        _ws = WebsiteContent(url=url)
        try:
            _ws.content = visit_url_internal(url, llm=llm)
        except Exception as e:
            # Preserve the actual exception information
            _ws.content = f"x Error visiting website {url}: {type(e).__name__}: {str(e)}"
        if not _ws.content.strip():
            _ws.content = f"x Error visiting website {url}: extraction returned empty content"
        results.append(_ws)
    return results

visit_urls_tool = LlmTool(
    visit_urls,
    name = "visit_urls",
    description="""
Fetch content of web page urls and extract their main information content.
Use this tool if you want to fetch specific information from some web page.
    """,
    parameters=[
        LlmToolParameter(name="urls", description="A list of urls to visit", type="list[str]")
    ],
    required_parameters=["urls"]
)

