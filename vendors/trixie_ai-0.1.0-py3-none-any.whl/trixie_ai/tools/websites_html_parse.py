import json
import os
import subprocess
import sys
from typing import Any

from trixie_ai.tools.websites_sandbox_worker import validate_source, ExtractionError, UnsafeCodeError

try:
    import resource  # POSIX only
except ImportError:  # pragma: no cover - Windows has no resource module
    resource = None  # type: ignore[assignment]

DEFAULT_TIMEOUT_SECONDS = 5.0
DEFAULT_MEMORY_LIMIT_BYTES = 1024 * 1024 * 1024  # 1 GB

WORKER_SCRIPT = os.path.join(os.path.dirname(__file__), "websites_sandbox_worker.py")

def run_extraction(
    extract_code: str,
    html_code: str,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    memory_limit_bytes: int = DEFAULT_MEMORY_LIMIT_BYTES,
) -> Any:
    if not isinstance(extract_code, str) or not extract_code.strip():
        raise ValueError("extract_code must be a non-empty string")
    if not isinstance(html_code, str):
        raise ValueError("html_code must be a string")

    validate_source(extract_code)

    request = json.dumps({
        "source": extract_code,
        "html": html_code,
        "memory_limit_bytes": memory_limit_bytes,
        "timeout_seconds": timeout_seconds,
    })

    try:
        completed = subprocess.run(
            [sys.executable, WORKER_SCRIPT],
            input=request,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
        )
    except subprocess.TimeoutExpired as exc:
        raise ExtractionError(f"execution exceeded {timeout_seconds}s timeout") from exc

    if completed.returncode != 0:
        raise ExtractionError(
            f"worker crashed with exit code {completed.returncode}: {completed.stderr.strip()}"
        )

    try:
        response = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise ExtractionError(f"worker produced invalid output: {completed.stdout!r}") from exc

    status, payload = response["status"], response["payload"]

    if status == "ok":
        try:
            return json.loads(payload)
        except Exception as exc:
            raise ExtractionError("worker returned invalid JSON") from exc
    if status == "unsafe":
        raise UnsafeCodeError(payload)
    raise ExtractionError(payload)


if __name__ == "__main__":
    good_code = """
def extract_content(html_code):
    import re
    match = re.search(r"<title>(.*?)</title>", html_code)
    return {"title": match.group(1) if match else None, "length": len(html_code)}
"""
    print(run_extraction(good_code, "<html><head><title>Hello</title></head></html>", timeout_seconds=100.0))

    malicious_import = """
def extract_content(html_code):
    import os
    return os.listdir("/")
"""
    try:
        run_extraction(malicious_import, "<html></html>")
    except UnsafeCodeError as error:
        print(f"Successfully blocked import: {error}")

    dunder_escape = """
def extract_content(html_code):
    return ().__class__.__bases__[0].__subclasses__()
"""
    try:
        run_extraction(dunder_escape, "<html></html>")
    except UnsafeCodeError as error:
        print(f"Successfully blocked dunder escape: {error}")

    format_escape = """
def extract_content(html_code):
    return "{0.__class__}".format(html_code)
"""
    try:
        run_extraction(format_escape, "<html></html>")
    except UnsafeCodeError as error:
        print(f"Successfully blocked format-string escape: {error}")

    infinite_loop = """
def extract_content(html_code):
    while True:
        pass
"""
    try:
        run_extraction(infinite_loop, "<html></html>", timeout_seconds=1.0)
    except ExtractionError as error:
        print(f"Successfully timed out: {error}")

    missing_function = """
def wrong_name(html_code):
    return html_code
"""
    try:
        run_extraction(missing_function, "<html></html>")
    except UnsafeCodeError as error:
        print(f"Successfully blocked missing function: {error}")
