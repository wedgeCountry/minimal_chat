import logging
from dataclasses import dataclass
from typing import List

from trixie_ai.model import LlmTool, LlmToolParameter

logger = logging.getLogger(__name__)

STOP_SUBJECTS = {"man", "ich", "du", "er", "sie", "es", "wir", "ihr"}

_NOISE_TAGS = {
    "script", "style", "nav", "header", "footer", "aside",
    "form", "iframe", "noscript", "svg", "figure",
}
_MAIN_SELECTORS = [
    "main", "article",
    '[role="main"]', '[role="article"]',
    "#content", "#main", "#article",
    ".content", ".main", ".article", ".post",
]
_USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "Chrome/120.0.0.0 Safari/537.36"
)

def wiki_search(key_word: str, language:str, sentences=5) -> str:
    key_word = key_word.strip()
    return _wiki_summary(key_word, language=language, sentences=sentences)

wiki_search_tool = LlmTool(
        wiki_search,
        name="wiki_search",
        description="""
Get a Wikipedia summary for a topic.

Use this to retrieve encyclopedia-style information about people, places, concepts,
events, or anything with a Wikipedia article. Returns a concise summary rather than
the full article.        
        """,
        parameters=[
            LlmToolParameter(name="key_word", description="Search key word on the wikipedia site", type="str"),
            LlmToolParameter(name="language", description="Language settings of the wikipedia site. Possible values: ['de', 'en', 'es', 'fr']", type="str"),
            LlmToolParameter(name="sentences", description="Length of the summary in number of sentences. Use 2-3 for brief overview, 5-10 for detailed summary. Default=3", type="str"),
        ],
        required_parameters=["key_word", "language"]
    )

def _wiki_summary(key_word: str, language:str="en", sentences:int=3) -> str:
    """
    Get a Wikipedia summary for a topic.

    Use this to retrieve encyclopedia-style information about people, places, concepts,
    events, or anything with a Wikipedia article. Returns a concise summary rather than
    the full article.

    Args:
        key_word: Topic to look up. Use the most common/official name. Examples:
            - "Albert Einstein"
            - "Python (programming language)"
            - "World War II"
            - "photosynthesis"
        language: Wikipedia language edition (default: "en").
            Use "de" for German, "es" for Spanish, "fr" for French, etc.
        sentences: Number of sentences to return (default: 5).
            Use 2-3 for brief overview, 5-10 for detailed summary.

    Returns:
        Summary text from Wikipedia, or empty string if article not found.

    Examples:
        _wiki_summary("Marie Curie")
        _wiki_summary("Berlin", language="de", sentences=3)
        _wiki_summary("machine learning", sentences=10)
    """
    from wikipedia import wikipedia
    wikipedia.set_lang(language)
    try:
        # TODO: Parse Info Box!
        return wikipedia.summary(key_word, sentences=sentences)
    except wikipedia.DisambiguationError as e:
        best = _best_disambiguation_option(key_word, e.options)
        logging.warning(f"Ambiguous — '{key_word}'. Best match: '{best}' (from: {', '.join(e.options[:3])})")
        try:
            # TODO: Parse Info Box!
            return wikipedia.summary(best, sentences=sentences, auto_suggest=False)
        except (wikipedia.DisambiguationError, wikipedia.PageError) as inner:
            logging.error(f"Disambiguation fallback failed for '{best}': {inner}")
            return ""
    except wikipedia.PageError:
        logging.warning(f"No Wikipedia page found for '{key_word}'.")
        return ""

def _best_disambiguation_option(key_word: str, options: list[str]) -> str:
    """Return the option most semantically similar to the original keyword."""
    ranked = score_keywords(key_word, options[:10])
    return ranked[0][0] if ranked else options[0]

_embed_model = None
def get_embed_model():
    global _embed_model

    from sentence_transformers import SentenceTransformer
    if _embed_model is None:
        _embed_model = SentenceTransformer("paraphrase-multilingual-MiniLM-L12-v2")
    return _embed_model

def score_keywords(prompt: str, keywords: List[str]) -> List[tuple]:
    model = get_embed_model()

    prompt_embedding = model.encode(prompt, convert_to_tensor=True)
    keyword_embeddings = model.encode(keywords, convert_to_tensor=True)

    from sentence_transformers import util
    scores = util.cos_sim(prompt_embedding, keyword_embeddings)[0]

    ranked = sorted(
        zip(keywords, scores.tolist()),
        key=lambda x: x[1],
        reverse=True
    )
    return ranked  # [("Krebs", 0.91), ("Krankheit", 0.74), ...]
