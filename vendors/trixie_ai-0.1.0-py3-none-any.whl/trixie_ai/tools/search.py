import logging
from dataclasses import dataclass
from typing import List

import httpx
from bs4 import BeautifulSoup

from trixie_ai.model import LlmTool, LlmToolParameter

logger = logging.getLogger(__name__)

_BLOCKED_SOURCES = ["wikipedia.org", "grokipedia.com"]
_UNICODE_HYPHENS = str.maketrans("‐‑‒–—―﹣－", "--------") # Unicode hyphens the LLM sometimes produces; normalise to plain ASCII hyphen

@dataclass
class DDGSResult:
    source: str
    title: str
    summary: str
    extended_summary: str|None = None
    website_content: str|None = None

def ddgs(query: str, region: str = "de-de", max_results: int = 10, ) -> list[DDGSResult]:

    from ddgs import DDGS
    raw = DDGS().text(query=query, region=region.lower(), max_results=max_results, )

    return [
        DDGSResult(
            source = r.get("href", ""),
            title = r.get("title", ""),
            summary = r.get("body", "")
        )

        for r in (raw or [])
        if r.get("title")
        and r.get("body")
        and r.get("href", "").startswith("http")
        and not any(
            blocked in r.get("href", "")
            for blocked in _BLOCKED_SOURCES
        )
    ]

def ddgs_httpx(search: str, region:str = "de-de", max_results: int = 10) -> list[DDGSResult]:
    query = search.translate(_UNICODE_HYPHENS).strip()
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
    }
    params = {"q": query, "kl": region.lower()}
    r = httpx.get("https://html.duckduckgo.com/html/", params=params, headers=headers)
    r.raise_for_status()

    soup = BeautifulSoup(r.text, "html.parser")
    results = []
    for result in soup.select(".result__body")[:max_results]:
        title = result.select_one(".result__title")
        snippet = result.select_one(".result__snippet")
        url = result.select_one(".result__a")
        source = (url.get("href") if url and url.get("href", "").startswith("http") else "").strip()
        if not source or any(b in source for b in _BLOCKED_SOURCES):
            continue
        if title and snippet:
            results.append(DDGSResult(source, title.get_text().strip(), snippet.text.strip()))

    if not results:
        raise Exception(f"DDG HTML returned 0 results for '{query}' (HTTP {r.status_code})")

    return results

@dataclass
class DDGSearchResult:
    query: str
    results: list[DDGSResult]|str

def _detect_language(text: str) -> str:
    from langdetect import detect
    return detect(text)

def search(search_queries: List[str], max_results: int = 10) -> list[DDGSearchResult]:
    import time
    search_results = []
    for query in search_queries:

        detected_language = _detect_language(query)

        if detected_language == "de":
            region = "de-de"
        elif detected_language == "en":
            region = "en-us"
        else:
            # Fall back to English for unrecognized languages
            logger.warning(f"Unrecognized language '{detected_language}' for query '{query}', defaulting to English")
            region = "en-us"

        search_result = DDGSearchResult(query, [])

        def do_search():
            try:
                try:
                    return ddgs(query, region=region, max_results=max_results)
                except Exception as e:
                    return ddgs_httpx(query, region=region, max_results=max_results)
            except Exception as e:
                return f"x Error in search: {e}"

        search_result.results = do_search()
        
        # Retry once after 5 seconds if we got 0 results
        if isinstance(search_result.results, list) and len(search_result.results) == 0:
            logger.warning(f"No results for '{query}', retrying after 5 seconds...")
            time.sleep(5)
            search_result.results = do_search()

        search_results.append(search_result)

    return search_results

search_tool = LlmTool(
    search,
    name="search",
    description="""
Search the web. Use this tool when you need current information from the web, facts that may have
changed since your knowledge cutoff, or information about recent events. It returns a list of results. 
For each search query it returns up to top_k search results, each with source, title, and summary.    
    """,
    parameters=[
        LlmToolParameter(name="search_queries", description="The list of search queries. In each query, use 2-6 words for best results.", type="list[str]"),
        LlmToolParameter(name="max_results", description="The number of search results to use. Default = 10", type="int")
    ],
    required_parameters=["search_queries"])

