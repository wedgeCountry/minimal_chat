"""Extract a simplified structure from an HTML page and return it as HTML.

Text nodes longer than `text_limit` characters are truncated. Runs of
repeated sibling elements (e.g. <li> in a <ul>, <tr> in a <table>, or
repeated div "cards") are treated as lists and truncated to the first
`list_limit` items, leaving a comment noting how many were removed.
"""
import asyncio
import concurrent.futures
import logging
import random
import re
from typing import List

import httpx
from bs4 import BeautifulSoup
from bs4 import Comment, Tag

from trixie_ai.backend import call_llm
from trixie_ai.config import get_default_config
from trixie_ai.context import LlmContext
from trixie_ai.model import LlmDefinition
from trixie_ai.tools.websites_html_parse import run_extraction
from trixie_ai.tools.websites_sandbox_worker import ALLOWED_IMPORT_MODULES

logger = logging.getLogger(__name__)



TEXT_CHAR_LIMIT = 100
LIST_ITEM_LIMIT = 2

# User agent rotation list
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/120.0.0.0 Safari/537.36",
]

def get_random_user_agent() -> str:
    """Get a random user agent from the rotation list."""
    return random.choice(USER_AGENTS)


# Timeout configuration (in seconds)
HTTPX_TIMEOUT = 30.0
PLAYWRIGHT_TIMEOUT = 45.0
PLAYWRIGHT_PAGE_LOAD_TIMEOUT = 20000  # ms
PLAYWRIGHT_WAIT_TIMEOUT = 5000  # ms
STRIPPED_TAGS = {
    "script", "style", "noscript", "svg", "canvas",
    "iframe", "meta", "link", "button", "nav", "sup",
    "dialog", "template",
}

_OVERLAY_KEYWORD_RE = re.compile(
    r"cookie|consent|gdpr|ccpa|onetrust|trustarc|quantcast|modal|overlay|popup"
    r"|interstitial|paywall|newsletter|dialog",
    re.IGNORECASE,
)

def _is_overlay_tag(tag: Tag) -> bool:
    if getattr(tag, "attrs", None) is None:
        return False  # already decomposed as part of a removed parent
    if tag.get("role") in ("dialog", "alertdialog") and str(tag.get("aria-modal", "")).lower() == "true":
        return True
    parts = []
    for attr in ("id", "class", "role", "aria-label", "data-testid"):
        value = tag.get(attr)
        if isinstance(value, list):
            value = " ".join(value)
        if value:
            parts.append(str(value))
    return bool(_OVERLAY_KEYWORD_RE.search(" ".join(parts)))

def remove_overlay_elements(soup) -> int:
    """Remove cookie-consent banners, modal popups and similar overlays.

    Must run before attributes are stripped, because overlays are identified
    by their id/class/role attributes. Returns the number of removed tags.
    """
    removed = 0
    for tag in soup.find_all(True):
        if _is_overlay_tag(tag):
            tag.decompose()
            removed += 1
    return removed

def extract_html_structure(
    html: str,
    text_limit: int|None = TEXT_CHAR_LIMIT,
    list_limit: int|None = LIST_ITEM_LIMIT,
    do_strip_links: bool = True
) -> str:
    soup = BeautifulSoup(html, "html.parser")

    for tag in soup(STRIPPED_TAGS):
        tag.decompose()

    remove_overlay_elements(soup)

    for comment in soup.find_all(string=lambda node: isinstance(node, Comment)):
        comment.extract()

    for tag in soup.find_all(True):  # True matches all tags
        attr_items = list(tag.attrs)
        for attr in attr_items:
            if attr not in ["id", "name", "href"]:
                tag.attrs.pop(attr, None)

    for span in soup.find_all("span"):
        span.unwrap()

    for span in soup.find_all("p"):
        span.unwrap()

    for span in soup.find_all("label"):
        span.unwrap()

    # Replace links with their text content
    if do_strip_links:
        for link in soup.find_all("a"):
            link.unwrap()

    for tag in soup.find_all():
        if tag.name not in ("br", "img") and not tag.get_text(strip=True):
            tag.decompose()

    root = soup.find("body") or soup

    if list_limit is not None:
        _limit_lists(root, list_limit)
    if text_limit is not None:
        _truncate_text_nodes(root, text_limit)

    formatted = re.sub("\n+", "\n", re.sub("[ ]+", " ", str(root)))
    return formatted


def _limit_lists(tag: Tag, list_limit: int) -> None:
    """Cap runs of consecutive same-tag siblings at list_limit, removing the
    rest and leaving a comment noting how many were dropped."""
    child_tags = [child for child in tag.contents if isinstance(child, Tag)]

    index = 0
    while index < len(child_tags):
        tag_name = child_tags[index].name
        run_end = index + 1
        while run_end < len(child_tags) and child_tags[run_end].name == tag_name:
            run_end += 1

        run = child_tags[index:run_end]
        if len(run) > list_limit:
            omitted = run[list_limit:]
            marker = Comment(f" +{len(omitted)} more <{tag_name}> omitted ")
            run[list_limit - 1].insert_after(marker)
            for element in omitted:
                element.extract()

        index = run_end

    for child in [c for c in tag.contents if isinstance(c, Tag)]:
        _limit_lists(child, list_limit)


def _truncate_text_nodes(tag: Tag, text_limit: int) -> None:
    for node in tag.find_all(string=False):
        node.decompose()

    for node in tag.find_all(string=True):
        if isinstance(node, Comment):
            continue
        if len(node) > text_limit:
            marker = Comment(f" +{len(node) - text_limit} more chars omitted ")
            node.replace_with(node[:text_limit] + f"[...{marker}...] \n ")



def extract_contents_simple(html_code, llm: LlmDefinition = None):
    llm = llm or get_default_config().lm_studio
    try:
        context = LlmContext()
        context.add_system_prompt("You are a html search assistant.")

        context.add_message("user", """```html\n%s\n```""" % html_code)

        result = call_llm(llm, "Extract all relevant information of the website in a markdown format. leave out all irrelevant information, site elements and ads.", context, reasoning=False)
        return result
    except Exception as e:
        logger.error(f"Error in extract_contents_simple: {e}")
        # Fallback to simple text extraction
        return extract_content(html_code)



EXTRACTOR_SYSTEM_PROMPT = """
You are a skilled python assistant. You think very shortly. You will be asked to write an extractor function for a specific website. 
The code must be tailored towards that specific web site. Do not use comments. Allowed python imports: %s. You focus on creating correct python.
""" % ", ".join(ALLOWED_IMPORT_MODULES)

DEFAULT_EXTRACTOR_PROMPT = """  
Look for tags and/or selectors in the provided html document that contain the main information content of the site. (The content is stripped to save tokens.)
Remove tags that are site navigation elements, unrelated information, advertisements, cookie banners or popups. 
Then write a short python function called "extract_content(html_code: str)" that uses beautiful soup to extract exactly the contents of those selected elements!  
Do not return explanations. Return only the code for the function "extract_content". Return it as plain text. 
"""

def extract_contents(html_code, llm: LlmDefinition = None):
    llm = llm or get_default_config().lm_studio
    try:
        context = LlmContext()
        context.add_system_prompt(EXTRACTOR_SYSTEM_PROMPT)

        simplified_html_shortened = extract_html_structure(html_code, text_limit=50, list_limit=3)

        #print(simplified_html_shortened)

        context.add_message("user", """```html\n%s\n```""" % simplified_html_shortened)

        result = call_llm(llm, DEFAULT_EXTRACTOR_PROMPT, context, reasoning=False)

        #print(result.reasoning_content)

        found = re.findall(r"[`]{3}python\s([^`]*)[`]{3}", result.content)
        if found:
            python_code = found[0]
        else:
            python_code = result.content

        #print(python_code)

        try:
            simplified_html = extract_html_structure(html_code, text_limit=None, list_limit=None, do_strip_links=False)
            extraction = run_extraction(python_code, simplified_html, timeout_seconds=30)
        except Exception as e:
            logger.error(f"Error in run_extraction: {e}")
            return f"x Error: {e}"

        return extraction
    except Exception as e:
        logger.error(f"Error in extract_contents: {e}")
        # Fallback to simple text extraction
        return extract_content(html_code)


async def fetch_html_playwright_async(url: str, timeout: float = PLAYWRIGHT_TIMEOUT) -> str:
    from playwright.async_api import async_playwright
    browser = None
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(
                headless=True,
                timeout=int(timeout * 1000)  # Convert to ms
            )

            page = await browser.new_page()

            user_agent = get_random_user_agent()
            await page.set_extra_http_headers({
                "User-Agent": user_agent,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
            })

            try:
                await page.goto(
                    url,
                    wait_until="domcontentloaded",
                    timeout=PLAYWRIGHT_PAGE_LOAD_TIMEOUT,
                )
            except Exception as goto_error:
                logger.warning(f"Playwright goto failed for {url}: {goto_error}, retrying with longer timeout")
                await page.goto(
                    url,
                    wait_until="domcontentloaded",
                    timeout=PLAYWRIGHT_PAGE_LOAD_TIMEOUT * 2,
                )

            await page.wait_for_timeout(PLAYWRIGHT_WAIT_TIMEOUT)

            return await page.content()
    except Exception as e:
        message = str(e)
        if "Executable doesn't exist" in message or "playwright install" in message:
            raise Exception(
                f"Playwright browser binary is missing for {url} - run 'playwright install chromium' first ({e})"
            )
        if isinstance(e, (asyncio.TimeoutError, TimeoutError)):
            raise Exception(f"Playwright timeout for {url} after {timeout}s")
        logger.error(f"Playwright error for {url}: {e}")
        raise
    finally:
        if browser is not None:
            try:
                await browser.close()
            except Exception:
                pass


def fetch_html_playwright(url: str, timeout: float = PLAYWRIGHT_TIMEOUT) -> str:
    """Fetch a page with headless Chromium.

    The async Playwright driver runs in a dedicated thread with its own event
    loop via asyncio.run(), so this works from plain sync code and from inside
    an already-running event loop (e.g. FastAPI async handlers) alike.
    """
    def _run() -> str:
        return asyncio.run(fetch_html_playwright_async(url, timeout))

    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    try:
        return executor.submit(_run).result(timeout=timeout + 5)
    except concurrent.futures.TimeoutError:
        raise Exception(f"Playwright timeout for {url} after {timeout}s")
    finally:
        executor.shutdown(wait=False)


def fetch_html_httpx(url: str, timeout: float = HTTPX_TIMEOUT) -> str:
    # Rotate user agent for each request
    user_agent = get_random_user_agent()
    
    headers = {
        "User-Agent": user_agent,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate",  # Remove br (Brotli) to avoid decoding issues
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
    }

    try:
        # Configure httpx with proper timeout settings
        httpx_timeout = httpx.Timeout(
            connect=timeout * 0.3,  # 30% of total timeout for connection
            read=timeout * 0.5,     # 50% for reading response
            write=timeout * 0.2,    # 20% for writing request
            pool=timeout * 0.5      # 50% for connection pool
        )
        
        with httpx.Client(
                http2=True,
                follow_redirects=True,
                headers=headers,
                timeout=httpx_timeout,
        ) as client:
            response = client.get(url)
            response.raise_for_status()

            # Handle content encoding
            content = response.text

            # If content looks like binary data, try to decode it
            if not content or content.startswith('\x1f\x8b') or content.startswith('\x00'):
                # Try to get raw bytes and decode
                raw_content = response.content
                try:
                    content = raw_content.decode('utf-8')
                except UnicodeDecodeError:
                    # Try other encodings
                    for encoding in ['latin-1', 'utf-16', 'utf-32']:
                        try:
                            content = raw_content.decode(encoding)
                            break
                        except UnicodeDecodeError:
                            continue

            return content
    except httpx.ConnectTimeout:
        logger.warning(f"httpx connection timeout for {url} after {timeout}s")
        raise Exception(f"Connection timeout for {url} after {timeout}s")
    except httpx.ReadTimeout:
        logger.warning(f"httpx read timeout for {url} after {timeout}s")
        raise Exception(f"Read timeout for {url} after {timeout}s")
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 403:
            logger.warning(f"httpx HTTP 403 Forbidden for {url} - access denied")
        else:
            logger.warning(f"httpx HTTP error for {url}: {e.response.status_code} - {e.response.reason_phrase}")
        raise
    except Exception as e:
        logger.warning(f"httpx failed for {url}: {e}")
        raise

def fetch_html(url: str, httpx_timeout: float = HTTPX_TIMEOUT, playwright_timeout: float = PLAYWRIGHT_TIMEOUT) -> str:
    try:
        return fetch_html_httpx(url, timeout=httpx_timeout)
    except Exception as e:
        logger.info(f"Falling back to Playwright for {url} after httpx failure: {e}")
        try:
            return fetch_html_playwright(url, timeout=playwright_timeout)
        except Exception as e2:
            logger.error(f"Both httpx and Playwright failed for {url}: httpx={e}, playwright={e2}")
            raise Exception(f"Failed to fetch {url} with both httpx and Playwright (httpx: {e} | playwright: {e2})")


def visit_url_internal(url: str, httpx_timeout: float = HTTPX_TIMEOUT, playwright_timeout: float = PLAYWRIGHT_TIMEOUT, llm: LlmDefinition = None) -> str:
    try:
        # Check if this is a PDF URL first
        if _is_pdf_url(url):
            try:
                from services.pdf_extraction import extract_pdf_content
                logger.info(f"Detected PDF URL: {url}, attempting PDF extraction")
                pdf_text = extract_pdf_content(url, timeout=httpx_timeout)
                return pdf_text
            except ImportError:
                logger.warning("PDF extraction module not available, falling back to HTML fetch")
            except Exception as pdf_error:
                logger.warning(f"PDF extraction failed for {url}: {pdf_error}, falling back to HTML fetch")
        
        # Regular HTML fetching
        result = fetch_html(url, httpx_timeout=httpx_timeout, playwright_timeout=playwright_timeout)
        # Decoded HTML text
        escaped_html = repr(result)
        #return extract_content(escaped_html)
        return extract_contents(escaped_html, llm=llm)
    except Exception as e:
        logger.error(f"Error in visit_url_internal for {url}: {e}")
        raise Exception(f"Failed to visit {url}: {str(e)}")


def _is_pdf_url(url: str) -> bool:
    """Check if a URL points to a PDF file."""
    url_lower = url.lower()
    return (url_lower.endswith('.pdf') or 
            '/pdf/' in url_lower or 
            '?format=pdf' in url_lower or
            '&format=pdf' in url_lower)


def extract_content(html_code: str):
    soup = BeautifulSoup(html_code, 'html.parser')
    remove_overlay_elements(soup)

    main_content_elements = soup.find(['article', 'main', 'div'], class_=re.compile(r'(content|body)'))

    if main_content_elements:
        textes = [p.get_text() for p in main_content_elements.find_all(['p', 'h1', 'h2', 'li'])]
        return '\n\n'.join(filter(None, textes))

    # Fallback if specific containers are not found
    body = soup.find('body')
    if body:
        textes = [p.get_text() for p in body.find_all(['p', 'h1', 'h2'])]
        return '\n\n'.join(filter(None, textes))

    return ""

if __name__ == "__main__":
    sample_html = """
    <html><body>
        <h1>Product Catalog</h1>
        <p>This paragraph is intentionally long so that we can verify that
        the truncation logic correctly cuts it down to exactly one hundred
        characters and appends an ellipsis marker.</p>
        <ul>
            <li>Apples</li>
            <li>Bananas</li>
            <li>Cherries</li>
            <li>Dates</li>
        </ul>
        <table>
            <tr><td>Row 1</td></tr>
            <tr><td>Row 2</td></tr>
            <tr><td>Row 3</td></tr>
        </table>
        <div class="card">Card A</div>
        <div class="card">Card B</div>
        <div class="card">Card C</div>
        <div class="card">Card D</div>
    </body></html>
    """

    #structure = extract_html_structure(sample_html)
    #print(structure)

    print("------------------------------")
    #print(extract_contents(sample_html))

    extracted = visit_url_internal("https://www.unisg.ch/de/newsroom/artificial-general-intelligence-agi-ist-auf-dem-vormarsch/", httpx_timeout=60, playwright_timeout=90)
    print(extracted)


#Calling visit_urls({"urls":["https://www.unisg.ch/de/newsroom/artificial-general-intelligence-agi-ist-auf-dem-vormarsch/"]})
