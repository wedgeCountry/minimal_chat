import logging
from typing import List

from trixie_ai.backend import call_llm, _get_llm_response, _collect_tool_results
from trixie_ai.config import get_default_config
from trixie_ai.context import LlmContext
from trixie_ai.model import LlmTool, LlmToolParameter, LlmDefinition
from trixie_ai.tools.search import DDGSearchResult, search, DDGSResult
from trixie_ai.tools.summary import summarize_text_content
from trixie_ai.tools.websites import visit_urls

logger = logging.getLogger(__name__)

_BLOCKED_SOURCES = ["wikipedia.org", "grokipedia.com"]
_UNICODE_HYPHENS = str.maketrans("‐‑‒–—―﹣－", "--------") # Unicode hyphens the LLM sometimes produces; normalise to plain ASCII hyphen


DEEP_SEARCH_SYSTEM_PROMPT = """
You are a search assistant. You select those search results that match the user question.
"""
DEEP_SEARCH_PROMPT = "Always call 'select_urls' tool with all urls that answer the search question the best."

def select_urls(search_query: str, search_results: list[DDGSResult]|str, llm: LlmDefinition = None):
    llm = llm or get_default_config().lm_studio
    context = LlmContext()
    context.add_system_prompt(DEEP_SEARCH_SYSTEM_PROMPT)

    results_str = "\n".join([f"url: {r_.source} summary: {r_.summary}" for r_ in search_results]) \
        if not isinstance(search_results, str) else search_results
    context.add_message("user", """```given search results\n%s\n```""" % repr(results_str))
    context.add_message("user", """```given question\n%s\n```""" % search_query)

    def dummy_select_url_tool(urls: list[str]) -> list[str]:
        print(urls)
        return urls

    select_url_tool = LlmTool(
        dummy_select_url_tool,
        name="select_urls",
        description="""Select relevant search results.""",
        parameters=[LlmToolParameter(name="urls", description="The list of selected urls", type="list[str]")],
        required_parameters=["urls"])

    def _call_llm(llm: LlmDefinition, prompt: str, context: LlmContext = None) -> list[str]:
        try:
            messages = (context or LlmContext()).compile(reasoning = False)
            messages.append({"role": "user","content": prompt})

            response = _get_llm_response(llm, {
                "messages": messages,
                "tools": [select_url_tool.to_dict()],
            })

            if response.finish_reason != "tool_calls":
                return []

            return _collect_tool_results(response, [select_url_tool])
        except Exception as e:
            logger.error(f"Error in select_urls LLM call: {e}")
            # Fallback: return all URLs if LLM selection fails
            if isinstance(search_results, list):
                return [r_.source for r_ in search_results]
            return []

    _urls = _call_llm(llm, DEEP_SEARCH_PROMPT, context)
    return _urls


def deep_search(search_queries: List[str], max_results: int = 5, summarize: bool = True, llm: LlmDefinition = None) -> list[DDGSearchResult]:
    llm = llm or get_default_config().lm_studio
    try:
        search_results:list[DDGSearchResult] = search(search_queries, max_results)

        for search_result in search_results:
            try:
                urls_to_visit = select_urls(search_result.query, search_result.results, llm=llm)
                print(urls_to_visit)

                if not urls_to_visit:
                    logger.warning(f"No URLs selected for query: {search_result.query}")
                    continue

                url_results = visit_urls(urls_to_visit, llm=llm)
                for res in search_result.results:
                    ws = None
                    for url_res in url_results:
                        if url_res.url == res.source:
                            ws = url_res
                            break

                    if ws is None:
                        continue

                    if summarize:
                        try:
                            res.extended_summary = summarize_text_content(search_result.query, ws.content, llm=llm)
                        except Exception as e:
                            res.extended_summary = f"x Error creating extended summary: {e}"
                    else:
                        res.website_content = ws.content
            except Exception as e:
                logger.error(f"Error processing search result for query '{search_result.query}': {e}")
                continue

        return search_results
    except Exception as e:
        logger.error(f"Error in deep_search: {e}")
        # Return empty results
        return [DDGSearchResult(query=query, results=[]) for query in search_queries]


deep_search_tool = LlmTool(
        deep_search,
        name="deep_search",
        description="""
Search the web using DuckDuckGo visiting result links. 

Use this tool when you need information from the web for deep questions, philosophical discussions, political debate, and for research task. 
It returns a list of results. For each search query it returns up to top_k search results, each with source, title, and summary.    
        """,
        parameters=[
            LlmToolParameter(name="search_queries", description="The list of search queries. In each query, use 2-6 words for best results.", type="list[str]"),
            LlmToolParameter(name="max_results", description="The number of search results to use. Default = 5", type="int"),
            LlmToolParameter(name="summarize", description="Shall the results be summarized? Use for very large websites, do not use when max_results is larger than 3. Default = True", type="int")
        ],
        required_parameters=["search_queries"])
deep_search_tool.is_long_running_task = True

