"""Configuration for Trixie AI.

At program startup a dotenv-style `.env` file is parsed into a `Config`
object which is handed to the application (see `web_api.py`). The rest of
the codebase, including the unit tests, works with `Config` instances and
never reads environment variables directly.
"""
import logging
import os
import re
import urllib.request
from dataclasses import dataclass, fields
from pathlib import Path
from typing import get_type_hints

from trixie_ai.model import LlmDefinition

DEFAULT_ENV_FILE = ".env"

logger = logging.getLogger(__name__)

_ASSIGNMENT_RE = re.compile(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$")
_QUOTED_RE = re.compile(r"^([\"'])(.*)\1\s*(?:#.*)?$")
_INLINE_COMMENT_RE = re.compile(r"\s+#.*$")
_VAR_REF_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


class EnvFileError(ValueError):
    """Raised when a .env file contains a line that cannot be parsed."""


def _resolve_value(raw: str, defined: dict[str, str]) -> str:
    raw = raw.strip()
    quoted = _QUOTED_RE.match(raw)
    if quoted:
        value = quoted.group(2)
    else:
        value = _INLINE_COMMENT_RE.sub("", raw).strip()
    if value in defined:
        return defined[value]
    return _VAR_REF_RE.sub(lambda m: defined.get(m.group(1), m.group(0)), value)


def parse_dotenv(path: str | Path) -> dict[str, str]:
    """Parse a dotenv-style file into a dict of string values.

    Supported syntax per line: blank lines, `#` comments, optional `export`
    prefix, `KEY = value` or `KEY=value`. Values may be single- or
    double-quoted (quotes are stripped, no escape processing) or bare.
    Unquoted values may carry a trailing ` # comment`. A bare value that
    matches a previously defined key resolves to that key's value, and
    `${KEY}` references inside values are substituted the same way.
    """
    path = Path(path)
    values: dict[str, str] = {}
    for lineno, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        match = _ASSIGNMENT_RE.match(line)
        if not match:
            raise EnvFileError(f"{path}:{lineno}: cannot parse line: {raw_line!r}")
        key, raw_value = match.groups()
        if raw_value[:1] in ("'", '"') and not _QUOTED_RE.match(raw_value.strip()):
            raise EnvFileError(f"{path}:{lineno}: unterminated quoted value: {raw_line!r}")
        values[key] = _resolve_value(raw_value, values)
    return values


@dataclass
class Config:
    """Application configuration, typically loaded from a .env file at startup."""

    trixie_lm_studio_host: str = "http://127.0.0.1:1234/v1"
    trixie_lm_studio_model: str = "openai/google/gemma-4-e4b"
    trixie_lm_studio_api_key: str = "lmstudio"
    trixie_strata_host: str = "http://127.0.0.1:8080/v1"
    trixie_strata_model: str = "qwen3.8-flash-next-iq3_s"
    trixie_strata_api_key: str = "strata"
    web_api_host: str = "127.0.0.1"
    web_api_port: int = 1235
    web_api_log_level: str = "INFO"

    @classmethod
    def from_mapping(cls, mapping: dict[str, str]) -> "Config":
        """Build a Config from a raw string mapping (env var name -> value)."""
        hints = get_type_hints(cls)
        kwargs = {}
        for f in fields(cls):
            env_name = f.name.upper()
            if env_name not in mapping:
                continue
            raw = mapping[env_name]
            ftype = hints[f.name]
            try:
                if ftype is int:
                    kwargs[f.name] = int(raw)
                elif ftype is float:
                    kwargs[f.name] = float(raw)
                elif ftype is bool:
                    kwargs[f.name] = str(raw).strip().lower() in ("1", "true", "yes", "on")
                else:
                    kwargs[f.name] = str(raw)
            except ValueError as e:
                raise ValueError(f"Invalid value for {env_name}: {raw!r} (expected {getattr(ftype, '__name__', ftype)})") from e
        return cls(**kwargs)

    @classmethod
    def from_env_file(cls, path: str | Path = DEFAULT_ENV_FILE) -> "Config":
        """Build a Config strictly from a .env file. Raises if the file is missing."""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Env file not found: {path}")
        return cls.from_mapping(parse_dotenv(path))

    @property
    def lm_studio(self) -> LlmDefinition:
        return LlmDefinition(api_base=self.trixie_lm_studio_host,
                             model=self.trixie_lm_studio_model,
                             api_key=self.trixie_lm_studio_api_key)

    @property
    def strata(self) -> LlmDefinition:
        return LlmDefinition(api_base=self.trixie_strata_host,
                             model=self.trixie_strata_model,
                             api_key=self.trixie_strata_api_key)

    def lmstudio_available(self, timeout: float = 1.0) -> LlmDefinition | None:
        return _probe(self.lm_studio, timeout, "LM studio")

    def strata_available(self, timeout: float = 1.0) -> LlmDefinition | None:
        return _probe(self.strata, timeout, "Strata")

    def pick_llm(self, timeout: float = 1.0) -> LlmDefinition:
        """Return the first reachable LLM backend: strata first, then LM studio."""
        llm = self.strata_available(timeout) or self.lmstudio_available(timeout)
        if llm is None:
            raise EnvironmentError("No LLM api available")
        return llm


def _probe(llm: LlmDefinition, timeout: float, label: str) -> LlmDefinition | None:
    try:
        req = urllib.request.Request(f"{llm.api_base}/models")
        req.add_header("Authorization", f"Bearer {llm.api_key}")
        urllib.request.urlopen(req, timeout=timeout)
        logger.debug("%s backend reachable at %s", label, llm.api_base)
        return llm
    except Exception as e:
        logger.debug("%s backend not reachable at %s: %s", label, llm.api_base, e)
        return None


def load_config(path: str | Path = DEFAULT_ENV_FILE) -> Config:
    """Load the Config from a .env file (if present).

    Real environment variables override file values for known keys.
    """
    mapping: dict[str, str] = {}
    p = Path(path)
    if p.exists():
        mapping.update(parse_dotenv(p))
    known = {f.name.upper() for f in fields(Config)}
    for key, value in os.environ.items():
        if key in known:
            mapping[key] = value
    return Config.from_mapping(mapping)


_default_config: "Config | None" = None


def get_default_config() -> Config:
    """Return the process-wide default Config, loading it from .env on first use."""
    global _default_config
    if _default_config is None:
        _default_config = load_config()
    return _default_config


def set_default_config(config: "Config | None") -> None:
    """Override the process-wide default Config (used by tests)."""
    global _default_config
    _default_config = config
