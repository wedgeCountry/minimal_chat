import base64
import enum
import json
from io import BytesIO
from typing import Callable, Any

import requests
from PIL import Image

from trixie_ai.context import LlmContext
from trixie_ai.model import LlmDefinition, LlmResponse, LlmTool


class UserCallbackLoggingLevel(enum.Enum):
    SILENT = "SILENT"
    MINIMAL = "MINIMAL"


class UserCallbackLogger:

    def __init__(self, user_callback: Callable[..., Any], mode: UserCallbackLoggingLevel=UserCallbackLoggingLevel.SILENT):
        self.user_callback = user_callback
        self.mode = mode

    def log(self, response: LlmResponse|str = None):
        if self.mode == UserCallbackLoggingLevel.SILENT:
            return None

        if not response:
            return self.user_callback("")

        if isinstance(response, str):
            return self.user_callback(response)

        if response.finish_reason == "tool_calls":
            return self.user_callback(
                "Calling " + ", ".join([t["function"]["name"] + "(" + t["function"]["arguments"] + ")" for t in response.tool_calls]))


def _get_llm_response(llm: LlmDefinition, payload: dict) -> LlmResponse:
    payload["model"] = llm.model
    headers = {"Authorization": f"Bearer {llm.api_key}"}
    response = requests.post(
        f"{llm.api_base}/chat/completions",
        json=payload,
        headers=headers
    )

    response.raise_for_status()
    response_payload = response.json()

    error_message = response_payload.get("error", None)
    if error_message: raise ConnectionError(error_message)

    choices = response_payload.get("choices", [dict()])

    if len(choices) != 1:
        raise ValueError("Unexpected length of choices! %s" % len(choices))

    response_message = choices[0].get("message", dict())
    finish_reason = choices[0].get("finish_reason", None)

    if finish_reason not in ["stop", "tool_calls"]:
        raise ValueError("Unexpected finish reason: %s" % finish_reason)

    content = response_message.get("content", None)
    reasoning_content = response_message.get("reasoning_content", None)
    tool_calls = response_message.get("tool_calls", [])

    return LlmResponse(content=content, reasoning_content=reasoning_content,
                       finish_reason=finish_reason, tool_calls=tool_calls)


def _prepare_messages(prompt: str, context: LlmContext, reasoning: bool, image: Image.Image) -> list[dict]:
    # load context
    messages = (context or LlmContext()).compile(reasoning)

    # make ready for image processing
    if image is not None:
        # limit the size of the image because the payload must not get too big!
        if min(image.size) > 512:
            image.thumbnail((512, 512), Image.Resampling.LANCZOS)

        buffer = BytesIO()
        image.save(buffer, format="PNG", quality=85)
        base64_image = base64.b64encode(
            buffer.getvalue()
        ).decode("utf-8")
        prompt = [{"type": "text", "text": prompt },
                   {"type": "image_url", "image_url": { "url": f"data:image/png;base64,{base64_image}" }}]

    # add user input
    messages.append({
        "role": "user",
        "content": prompt
    })
    return messages


def call_llm(llm: LlmDefinition, prompt: str, context: LlmContext = None, tools: list[LlmTool] = None, reasoning:bool = False, image: Image.Image = None, max_tool_call_loops: int = 20, logger: UserCallbackLogger=None, on_response: Callable[[LlmResponse], None] = None) -> LlmResponse:
    """

    max_tool_call_loops: How many tool calling loops to perform before breaking
    on_response: optional callback invoked with every LlmResponse, including
    intermediate tool_calls responses
    """
    logger = logger or UserCallbackLogger(lambda x: None)

    messages = _prepare_messages(prompt, context, reasoning, image)

    # get response from llm provider
    _tools = [t.to_dict() for t in tools or []]
    response = _get_llm_response(llm, {
            "messages": messages,
            "tools": _tools,
        })
    logger.log(response)
    if on_response:
        on_response(response)

    # tool calling loop

    reasoning_content = response.reasoning_content or ""
    tool_call_counter = 1
    while response.finish_reason != "stop" and tool_call_counter <= max_tool_call_loops:
        logger.log()
        messages.append({"role": "assistant", "tool_calls": response.tool_calls})

        tool_results = _collect_tool_results(response, tools, logger)
        messages.extend(tool_results)

        response = _get_llm_response(llm, {
            "messages": messages,
            "tools": _tools,
        })
        logger.log(response)
        if on_response:
            on_response(response)

        reasoning_content += response.reasoning_content or ""

        tool_call_counter += 1

    response.reasoning_content = reasoning_content
    return response


def _stream_llm_chunks(llm: LlmDefinition, payload: dict):
    """POST with stream=True and yield the parsed SSE chunks of an
    OpenAI-compatible chat completion as they arrive."""
    payload = dict(payload)
    payload["model"] = llm.model
    payload["stream"] = True
    headers = {"Authorization": f"Bearer {llm.api_key}"}
    response = requests.post(
        f"{llm.api_base}/chat/completions",
        json=payload,
        headers=headers,
        stream=True,
    )

    response.raise_for_status()
    response.encoding = "utf-8"

    for line in response.iter_lines(decode_unicode=True):
        if not line or not line.startswith("data:"):
            continue
        data = line[len("data:"):].strip()
        if data == "[DONE]":
            return
        if data:
            yield json.loads(data)


def _accumulate_tool_call_deltas(response: LlmResponse, tool_call_deltas: list) -> None:
    for tc in tool_call_deltas or []:
        index = tc.get("index", 0)
        while len(response.tool_calls) <= index:
            response.tool_calls.append({"id": None, "type": "function", "function": {"name": "", "arguments": ""}})
        entry = response.tool_calls[index]
        if tc.get("id"):
            entry["id"] = tc["id"]
        if tc.get("type"):
            entry["type"] = tc["type"]
        function = tc.get("function") or {}
        if function.get("name"):
            entry["function"]["name"] += function["name"]
        if function.get("arguments"):
            entry["function"]["arguments"] += function["arguments"]


def call_llm_stream(llm: LlmDefinition, prompt: str, context: LlmContext = None, tools: list[LlmTool] = None, reasoning: bool = False, image: Image.Image = None, max_tool_call_loops: int = 20, logger: UserCallbackLogger = None, on_response: Callable[[LlmResponse], None] = None):
    """
    Like call_llm, but streams from the backend. Yields (kind, payload) events
    as they arrive:
      ("delta", {"content": ...} / {"reasoning_content": ...})  live token deltas
      ("tool_calls", [...])  the full tool calls of a completed tool-call step
      ("tool_result", {...})  each tool result as soon as its tool finishes
      ("response", LlmResponse)  every completed agent step (on_response is
                                 also invoked with it)
    """
    logger = logger or UserCallbackLogger(lambda x: None)

    messages = _prepare_messages(prompt, context, reasoning, image)
    _tools = [t.to_dict() for t in tools or []]

    tool_call_counter = 1
    while True:
        response = LlmResponse(content="", reasoning_content="", finish_reason=None, tool_calls=[])
        for chunk in _stream_llm_chunks(llm, {"messages": messages, "tools": _tools}):
            error_message = chunk.get("error", None)
            if error_message:
                raise ConnectionError(error_message)

            choices = chunk.get("choices", [])
            if len(choices) > 1:
                raise ValueError("Unexpected length of choices! %s" % len(choices))
            if not choices:
                continue

            choice = choices[0]
            delta = choice.get("delta") or {}
            piece = delta.get("content")
            if piece:
                response.content += piece
                yield ("delta", {"content": piece})
            reasoning_piece = delta.get("reasoning_content")
            if reasoning_piece:
                response.reasoning_content += reasoning_piece
                yield ("delta", {"reasoning_content": reasoning_piece})
            _accumulate_tool_call_deltas(response, delta.get("tool_calls"))
            if choice.get("finish_reason"):
                response.finish_reason = choice["finish_reason"]

        if response.finish_reason is not None and response.finish_reason not in ["stop", "tool_calls"]:
            raise ValueError("Unexpected finish reason: %s" % response.finish_reason)

        logger.log(response)
        if on_response:
            on_response(response)
        yield ("response", response)

        if response.finish_reason == "stop" or response.finish_reason is None or tool_call_counter > max_tool_call_loops:
            return

        yield ("tool_calls", response.tool_calls)
        messages.append({"role": "assistant", "tool_calls": response.tool_calls})
        tool_results = []
        for index, (tool_name, result) in enumerate(_iter_tool_results(response, tools, logger)):
            tool_results.append(result)
            content_ = result["content"]
            yield ("tool_result", {"index": index, "tool_call_id": result["tool_call_id"],
                                   "name": tool_name, "content": content_})
        messages.extend(tool_results)
        tool_call_counter += 1


def _iter_tool_results(response, tools, logger=None):
    """Execute the response's tool calls one by one, yielding
    (tool_name, result_message) as each tool finishes."""
    logger = logger or UserCallbackLogger(lambda x: None)

    for tool_call in response.tool_calls:
        logger.log()

        if tool_call.get("type", None) != "function":
            raise ValueError("Unexpected tool call type: %s" % tool_call.get("type", None))

        _id = tool_call["id"]
        _function = tool_call["function"]
        tool = None
        for t in tools:
            if t.name == _function["name"]:
                tool = t
                break

        if not tool:
            raise RuntimeError("Unknown function name %s" % _function["name"])
        _arguments = json.loads(_function["arguments"])

        if tool.is_long_running_task:
            logger.log(f"Ich führe {tool.name} aus. Dies kann etwas länger dauern,  ich bitte deswegen um Geduld. Ich melde mich, wenn die Ergebnisse da sind.")

        try:
            valid_arg_names = [param.name for param in tool.parameters]
            valid_args = {k: v for k, v in _arguments.items() if k in valid_arg_names}
            tool_result = tool.callable(**valid_args)
        except Exception as e:
            tool_result = str(e)

        yield tool.name, {
            "role": "tool",
            "tool_call_id": _id,
            "content": str(tool_result)
        }


def _collect_tool_results(response, tools, logger=None):
    return [result for _, result in _iter_tool_results(response, tools, logger)]

