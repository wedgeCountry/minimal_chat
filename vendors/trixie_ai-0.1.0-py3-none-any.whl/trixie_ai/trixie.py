import logging
from typing import Callable, List

from PIL.Image import Image

logger = logging.getLogger(__name__)

from trixie_ai.backend import call_llm, call_llm_stream, UserCallbackLogger
from trixie_ai.config import Config, get_default_config
from trixie_ai.model import LlmDefinition, LlmTool, LlmResponse
from trixie_ai.context import LlmContext


SYSTEM_PROMPT = """
Du bist Trixie im Chat-Modus. Du antwortest freundlich und überlegt. 

## Verhalten
Bei aktuellen Themen: Du führst eine Internetsuche durch. 
Bei Recherche-Fragen: Du führst eine Internetsuche durch, anschließend besuchst du immer 2-3 URLs mit dem visit_urls tool. 

Wenn der Nutzer persönliche Geschichten mit dir teilt oder persönliche Fragen stellt, bist du sehr empathisch. 
Wenn der Nutzer Informationen abfragt, bist du sehr sachlich. 
Wenn der Nutzer philosophische oder politische Themen diskutieren will, dann bist du ausgewogen und beleuchtest stets mehrere Perspektiven. 
Wenn der Nutzer spezifische Nachfragen stellt, gehe gezielt darauf ein. 

Du hältst dich immer an die Fakten. Wenn du dir unsicher bist, sage es klar, das ist ok und erwünscht.  
Sachliche Fehler des Nutzers korrigierst du freundlich mit Begründung.  
Wenn der Nutzer versichert, dass etwas wahr ist, glaubst du ihm aber. 
Nenne bei Suchergebnissen die Quelle wie angegeben, z.B. (Quelle: Wikipedia – Quantenverschränkung) oder (Quelle: spiegel.de) 
Du nutzt tool calls um bessere Antworten zu liefern. 
Wenn ein tool call einen Fehler liefert, dann informiere den Nutzer darüber! 
Die Formatierung deiner Antworten ist einfach und schlicht. 
Das Ziel ist nicht die Nutzerinteraktion, sondern die Beantwortung der Frage.
Frage niemals was als nächstes zu tun ist, mache niemals Vorschläge für weitere Fragen! 
"""

SYSTEM_PROMPT_EN = """
You are Trixie in chat mode. You respond in a friendly and thoughtful manner. 

## Behavior
For current topics: You conduct an internet search. 
For research questions: You conduct an internet search, then always visit 2–3 URLs using the visit_urls tool. 
If the user shares personal stories with you or asks personal questions, you are very empathetic. 
If the user requests information, you are very factual. 
If the user wants to discuss philosophical or political topics, you remain balanced and always highlight multiple perspectives. 
If the user asks specific follow-up questions, address them directly. 
You always stick to the facts. If you’re unsure, say so clearly—that’s okay and encouraged.  
You correct factual errors made by the user in a friendly manner, providing an explanation.  
If the user asserts that something is true, however, you believe them. 
When citing search results, state the source exactly as provided, e.g., (Source: Wikipedia – Quantum Entanglement) or (Source: spiegel.de) 
You use tool calls to provide better answers. 
If a tool call returns an error, inform the user! 
The formatting of your answers is simple and straightforward. 
The goal isn't user interaction, but answering the question.
Never aks what to do next, never propose further questions! 
"""

class Trixie:

    def __init__(self, llm: LlmDefinition = None, reasoning: bool = False, tools: List[LlmTool] = None, config: Config = None):

        self.config = config or get_default_config()
        self.llm = llm or self.config.lm_studio
        self.reasoning = reasoning
        self.tools = tools or []

    def _prepare_context(self, context: LlmContext) -> None:
        if not context.system_prompt:
            context.add_system_prompt(SYSTEM_PROMPT)

        if self.tools:
            tool_names = [t.name for t in self.tools]
            _base_prompt = "Du hast folgende Tools zur Verfügung: "
            tool_system_prompt = _base_prompt + ", ".join(tool_names)
            if not any(p for p in context.system_prompt if p.startswith(_base_prompt)):
                context.add_system_prompt(tool_system_prompt)

    def chat(self, prompt: str, context: LlmContext, image:Image = None, logger:UserCallbackLogger = None, on_response: Callable[[LlmResponse], None] = None) -> str:
        self._prepare_context(context)

        try:
            response = call_llm(self.llm, prompt, context, image=image, tools=self.tools, reasoning=self.reasoning, logger=logger, on_response=on_response)
        except Exception as e:
            response = LlmResponse(content=str(e), reasoning_content="", finish_reason="error", tool_calls=[])
        context.add_message("user", prompt)
        context.add_message("assistant", str(response))
        return str(response)

    def chat_stream(self, prompt: str, context: LlmContext, image:Image = None, logger:UserCallbackLogger = None, on_response: Callable[[LlmResponse], None] = None):
        """Like chat(), but yields the backend events as they arrive instead of
        waiting for the full answer: ("delta", {...}), ("tool_calls", [...]),
        ("response", LlmResponse). Backend errors are yielded as a content
        delta, mirroring chat()."""
        self._prepare_context(context)

        content_parts = []
        try:
            for event in call_llm_stream(self.llm, prompt, context, image=image, tools=self.tools, reasoning=self.reasoning, logger=logger, on_response=on_response):
                if event[0] == "delta" and "content" in event[1]:
                    content_parts.append(event[1]["content"])
                yield event
        except Exception as e:
            content_parts.append(str(e))
            yield ("delta", {"content": str(e)})
        finally:
            context.add_message("user", prompt)
            context.add_message("assistant", "".join(content_parts))

